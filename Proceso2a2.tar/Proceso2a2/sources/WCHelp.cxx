///////////////////////////////////////////////////////////////////////////
//                                                                       //
// NOTICE OF COPYRIGHT                                                   //
//                                                                       //
//                       Copyright (C) 2018                              //
//           Ivan Castaneda - Julian Salamanca - Manuel Segura           //
//                                                                       //
//                idcastanedab@correo.udistrital.edu.co                  //
//                   jasalamanca@udistrital.edu.co                       //
//                                                                       //
//         Grupo de Fisica e Informatica (FISINFOR) Universidad          //
//                  Distrital Francisco Jose de Caldas                   //
//                                                                       //
//                                                                       //
//                https://github.com/fisinforgh/Proceso2a2.git           //
//                                                                       //
// This program is free software; you can redistribute it and/or modify  //
// it under the terms of the GNU General Public License as published by  //
// the Free Software Foundation; either version 2 of the License, or     //
// (at your option) any later version.                                   //
//                                                                       //
// This program is distributed in the hope that it will be useful,       //
// but WITHOUT ANY WARRANTY; without even the implied warranty of        //
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         //
// GNU General Public License for more details:                          //
//                                                                       //
//               http://www.gnu.org/copyleft/gpl.html                    //
//                                                                       //
///////////////////////////////////////////////////////////////////////////

//:::::::::::::::Clase para la interfaz auxiliar:::::::::::::::::::://
#include "../include/WCHelp.h"
//:::::::::::::::Construyendo la ventana:::::::::::::::::::::::::::://
WCHelp::WCHelp(const TGWindow *p, const TGWindow *main, UInt_t w, UInt_t h){
  
  fWCHelp=new TGTransientFrame(p,main,10,kVerticalFrame);
  fWCHelp->SetWindowName("Ayuda");  
  fWCHelp->Move(0,0);
  fWCHelp->SetWMSizeHints(984,583,2010,700,0,0);
  fWCHelp->Connect("CloseWindow()","WCHelp",this,"Close()");
  VFH=new TGVerticalFrame(fWCHelp,0);
  ECHelp=new TRootEmbeddedCanvas("Help",VFH,981,556);
  CHelp=ECHelp->GetCanvas();
  
  VFH->AddFrame(ECHelp,new TGLayoutHints(kLHintsTop| kLHintsExpandX| kLHintsExpandY,2,2,2,2));
  TBClose = new TGTextButton(VFH,"&Cerrar");
  TBClose->Connect("Clicked()","WCHelp",this,"Close()");
  VFH->AddFrame(TBClose, new TGLayoutHints(kLHintsCenterX| kLHintsBottom,2,2,2,2));

  fWCHelp->AddFrame(VFH,new TGLayoutHints(kLHintsExpandX| kLHintsExpandY,2,2,2,2));
  
  fWCHelp->MapSubwindows();
  fWCHelp->MapWindow();
}

WCHelp::~WCHelp(){delete fWCHelp;}
//:::::::::::::Escribiendo las indicaciones::::::::::::::::://
void WCHelp::Draw(){
  CHelp->Divide(2,1);
  PaveHelp[0]= new TPaveText(.02,.05,.99,1.0);
  PaveHelp[1]= new TPaveText(.02,.05,.99,1.0);
  CHelp->cd(1);
  PaveHelp[0]->AddText("Energ#acute{i}a del fot#acute{o}n: Entrada num#acute{e}rica,en unidades de GeV,"); 
  PaveHelp[0]->AddText(" con la cual se comienza a mover el fot#acute{o}n en el laboratorio.");
  PaveHelp[0]->AddText("-----------------------------------------------------------");
  PaveHelp[0]->AddText("N#acute{u}mero de eventos: Entrada num#acute{e}rica,");
  PaveHelp[0]->AddText("en la cual se establecen la cantidad de eventos que se quieren recrear.");
  PaveHelp[0]->AddText("-----------------------------------------------------------");
  PaveHelp[0]->AddText("Loope es el n#acute{u}mero de eventos de energ#acute{i}a");
  PaveHelp[0]->AddText("-----------------------------------------------------------");
  PaveHelp[0]->AddText("Reacci#acute{o}n: La fotoproducci#acute{o}n a energ#acute{i}a umbral,"); 
  PaveHelp[0]->AddText("con una reacci#acute{o}n 2 a 2, genera un bari#acute{o}n y un mes#acute{o}n,");
  PaveHelp[0]->AddText("se contemplan tres posibles reacciones, como son: ");
  PaveHelp[0]->AddText(" #gamma + p -> #Lambda_{0} + K^{+}");
  PaveHelp[0]->AddText(" #gamma + p -> p + #pi^{0}");
  PaveHelp[0]->AddText(" #gamma + p -> n + #pi^{+}");
  PaveHelp[0]->AddText("-----------------------------------------------------------");
  PaveHelp[0]->Draw();
    
  CHelp->cd(2);
  PaveHelp[1]->AddText("Entrada num#acute{e}rica que muestra el valor de cada una de las variables de Mandeltam S, T y U,"); 
PaveHelp[1]->AddText("tanto en el laboratorio como en el centro de masa.");
  PaveHelp[1]->AddText("-----------------------------------------------------------");
  PaveHelp[1]->AddText("Vec. momento: activa y desactiva la visualizaci#acute{o}n de los"); 
PaveHelp[1]->AddText("vectores del mom#acute{e}ntum lineal de cada una de las part#acute{i}culas.");
  PaveHelp[1]->AddText("-----------------------------------------------------------");
  PaveHelp[1]->AddText("Guardar: Activa y desactiva la opci#acute{o}n de guardar, sin embargo,"); 
  PaveHelp[1]->AddText("en cualquier caso, si al ejecutar la simulaci#acute{o}n"); 
PaveHelp[1]->AddText("no se ha ingresado ning#acute{u}n caracter a la entrada de"); 
PaveHelp[1]->AddText("texto el programa no guardar#acute{a} ning#acute{u}n archivo.");
  PaveHelp[1]->AddText("-----------------------------------------------------------");
  PaveHelp[1]->AddText("En la viasualizaci#acute{o}n el fot#acute{o}n est#acute{}a de color azul,");
  PaveHelp[1]->AddText("el prot#acute{o}n objetivo de color verde, el bari#acute{o}n de la");
  PaveHelp[1]->AddText("reacci#acute{o}n es de color amarillo y el mes#acuteon");
  PaveHelp[1]->AddText("de color rojo");
  PaveHelp[1]->Draw();
  CHelp->Update();
}
//:::::::::::::::::Cerrando la ventana:::::::::::::::://
void WCHelp::Close(){
  fWCHelp->CloseWindow();
}
