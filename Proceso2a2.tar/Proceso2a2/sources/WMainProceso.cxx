///////////////////////////////////////////////////////////////////////////
//                                                                       //
// NOTICE OF COPYRIGHT                                                   //
//                                                                       //
//                       Copyright (C) 2018                              //
//            Ivan Castaneda - Manuel Segura - Julian Salamanca          //
//                                                                       //
//                idcastanedab@correo.udistrital.edu.co                  //
//                   jasalamanca@udistrital.edu.co                       //
//                                                                       //
//         Grupo de Fisica e Informatica (FISINFOR) Universidad          //
//                  Distrital Francisco Jose de Caldas                   //
//                                                                       //
//                                                                       //
//                https://github.com/fisinforgh/Proceso2a2.git           //
//                                                                       //
// This program is free software; you can redistribute it and/or modify  //
// it under the terms of the GNU General Public License as published by  //
// the Free Software Foundation; either version 2 of the License, or     //
// (at your option) any later version.                                   //
//                                                                       //
// This program is distributed in the hope that it will be useful,       //
// but WITHOUT ANY WARRANTY; without even the implied warranty of        //
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         //
// GNU General Public License for more details:                          //
//                                                                       //
//               http://www.gnu.org/copyleft/gpl.html                    //
//                                                                       //
///////////////////////////////////////////////////////////////////////////
#include "../include/WMainProceso.h"


using namespace std;

WMainProceso::WMainProceso(const TGWindow *p, UInt_t w, UInt_t h)
{
   //::::::::::::Ventana principal::::::::::::::::::::::://
   MainFrame = new TGMainFrame(gClient->GetRoot(),
			       10,10,
			       kMainFrame |
			       kVerticalFrame);
   MainFrame->SetName("MainFrame");
   MainFrame->SetIconPixmap("/usr/share/proceso2a2/icono.jpeg");
   
   //::::::::::::::::::Marco vertical principal::::::::::://
   VFMain = new TGVerticalFrame(MainFrame,
				984,700,
				kVerticalFrame |
				kRaisedFrame);
   VFMain->SetName("VFMain");
   MainFrame->Connect("CloseWindow()","WMainProceso",this,"Exit()");
   MainFrame->SetWindowName("Proceso 2 a 2");
   //::::::Marco para visualizar los choques, los valores y los histogramas::::://
   HFViews = new TGHorizontalFrame(VFMain,
				   981,656,
				   kHorizontalFrame |
				   kRaisedFrame);
   HFViews->SetName("HFViews");

   //:::::Marco para  visualizar los choques y los valores:::://
   VFControl = new TGVerticalFrame(HFViews,
				   485,650,
				   kVerticalFrame |
				   kRaisedFrame);
   VFControl->SetName("VFControl");

   //::::::::::::::Marco para visualizar los choques:::::::::::::::://
   HFColision = new TGHorizontalFrame(VFControl,
				      479,370,
				      kHorizontalFrame);
   HFColision->SetName("HFColision");

   //::::::::Marco para los choques en el laboratorio::::::::://
   VFLab = new TGVerticalFrame(HFColision,
			       235,366,
			       kVerticalFrame);
   VFLab->SetName("VFLab");
   LLab = new TGLabel(VFLab,"Laboratorio");
   LLab->SetTextJustify(36);
   LLab->SetMargins(0,0,0,0);
   LLab->SetWrapLength(-1);
   VFLab->AddFrame(LLab, new TGLayoutHints(kLHintsLeft |
					   kLHintsTop |
					   kLHintsExpandX,
					   2,2,2,2));

   //:::::::::::.Canvas para los choques en el laboratorio:::::::/
   ECLab = new TRootEmbeddedCanvas("ECLab",
				   VFLab,231,339,
				   kSunkenFrame);
   wECLab = ECLab->GetCanvasWindowId();
   CLab = new TCanvas("CLab", 10, 10, wECLab);
   CLab->Range(-8,-8,8,8);
   ECLab->AdoptCanvas(CLab);
   VFLab->AddFrame(ECLab, new TGLayoutHints(kLHintsLeft |
					    kLHintsTop |
					    kLHintsExpandX |
					    kLHintsExpandY,
					    2,2,2,2));

   HFColision->AddFrame(VFLab, new TGLayoutHints(kLHintsLeft |
						 kLHintsTop |
						 kLHintsExpandX |
						 kLHintsExpandY,
						 2,2,2,2));

   //::::::::::Marco para los cchoques en el centro de masa:::::::::::://
   VFCM = new TGVerticalFrame(HFColision,236,366,kVerticalFrame);
   VFCM->SetName("VFCM");
   LCM = new TGLabel(VFCM,"Centro de masa");
   LCM->SetTextJustify(36);
   LCM->SetMargins(0,0,0,0);
   LCM->SetWrapLength(-1);
   VFCM->AddFrame(LCM, new TGLayoutHints(kLHintsLeft |
					 kLHintsTop |
					 kLHintsExpandX,
					 2,2,2,2));

   //::::::::::::::::Canvas para el choque en el centro de masa::::::::://
   ECCM = new TRootEmbeddedCanvas("ECCM",
				  VFCM,232,339,
				  kSunkenFrame);
   wECCM = ECCM->GetCanvasWindowId();
   CCM = new TCanvas("CCM", 10, 10, wECCM);
   CCM->Range(-8,-8,8,8);
   ECCM->AdoptCanvas(CCM);
   VFCM->AddFrame(ECCM, new TGLayoutHints(kLHintsLeft |
					  kLHintsTop |
					  kLHintsExpandX |
					  kLHintsExpandY,
					  2,2,2,2));
   
   HFColision->AddFrame(VFCM, new TGLayoutHints(kLHintsLeft |
						kLHintsTop |
						kLHintsExpandX |
						kLHintsExpandY,
						2,2,2,2));

   VFControl->AddFrame(HFColision, new TGLayoutHints(kLHintsLeft |
						     kLHintsTop |
						     kLHintsExpandX |
						     kLHintsExpandY,
						     2,2,2,2));

   // "Datos" group frame
   GFDatos = new TGGroupFrame(VFControl,"Datos");

   //Marco para datos de energia del haz y numero de eventos 
   HFDat = new TGHorizontalFrame(GFDatos,437,29,kHorizontalFrame);
   LEnFot = new TGLabel(HFDat,"Energ\355a del haz[GeV]");
   LEnFot->SetTextJustify(36);
   LEnFot->SetMargins(0,0,0,0);
   LEnFot->SetWrapLength(-1);
   HFDat->AddFrame(LEnFot, new TGLayoutHints(kLHintsLeft |
					     kLHintsTop |
					     kLHintsCenterY,
					     2,2,2,2));
   NEEnFo = new TGNumberEntry(HFDat, (Double_t) 0.0,8,-1,
			      (TGNumberFormat::EStyle) 5,
			      (TGNumberFormat::EAttribute) 1,
			      (TGNumberFormat::ELimit) 0);
   NEEnFo->SetName("NEEnFo");
   NEEnFo->SetState(true);
   HFDat->AddFrame(NEEnFo, new TGLayoutHints(kLHintsLeft |
					     kLHintsTop,
					     2,2,2,2));
   NENE = new TGNumberEntry(HFDat, (Double_t) 0,8,-1,
			    (TGNumberFormat::EStyle) 0,
			    (TGNumberFormat::EAttribute) 1,
			    (TGNumberFormat::ELimit) 0);
   NENE->SetName("NENE");
   NENE->SetState(true);
   HFDat->AddFrame(NENE, new TGLayoutHints(kLHintsRight | kLHintsTop,2,2,2,2));
   LNE = new TGLabel(HFDat,"N\372mero de eventos");
   LNE->SetTextJustify(36);
   LNE->SetMargins(0,0,0,0);
   LNE->SetWrapLength(-1);
   HFDat->AddFrame(LNE, new TGLayoutHints(kLHintsRight |
					  kLHintsTop |
					  kLHintsCenterY,
					  2,2,2,2));

   GFDatos->AddFrame(HFDat, new TGLayoutHints(kLHintsLeft |
					      kLHintsTop |
					      kLHintsExpandX,
					      2,2,2,2));
   //:::::::::::::::Marco para la energia del foton:::::::://
   HFEn = new TGHorizontalFrame(GFDatos,437,29,kHorizontalFrame);
   LEn = new TGLabel(HFEn,"Energ\355a del fot\363n[GeV]");
   LEn->SetTextJustify(36);
   LEn->SetMargins(0,0,0,0);
   LEn->SetWrapLength(-1);
   HFEn->AddFrame(LEn, new TGLayoutHints(kLHintsLeft |
					 kLHintsTop |
					 kLHintsCenterY,
					 2,2,2,2));
   NEEn = new TGNumberEntry(HFEn, (Double_t) 0.0,8,-1,
			    (TGNumberFormat::EStyle) 5,
			    (TGNumberFormat::EAttribute) 0,
			    (TGNumberFormat::ELimit) 0);
   NEEn->SetName("NEEn");
   NEEn->SetState(false);
   HFEn->AddFrame(NEEn, new TGLayoutHints(kLHintsLeft |
					  kLHintsTop,2,2,2,2));
   GFDatos->AddFrame(HFEn, new TGLayoutHints(kLHintsLeft |
					     kLHintsTop |
					     kLHintsExpandX
					     ,2,2,2,2));

   //::::Marco para el numero de eventos de energia y la reaccion:::::// 
   HFFile = new TGHorizontalFrame(GFDatos,437,29,kHorizontalFrame);
   LLoop = new TGLabel(HFFile,"Loop");
   LLoop->SetTextJustify(36);
   LLoop->SetMargins(0,0,0,0);
   LLoop->SetWrapLength(-1);
   HFFile->AddFrame(LLoop, new TGLayoutHints(kLHintsLeft |
					      kLHintsTop,
					      2,2,2,2));
   NELoop = new TGNumberEntry(HFFile, (Double_t) 1,8,-1,
			       (TGNumberFormat::EStyle) 0,
			       TGNumberFormat::kNEANonNegative,
			       TGNumberFormat::kNELLimitMin,0);
   NELoop->SetName("NELoop");
   NELoop->SetState(kTRUE);
   HFFile->AddFrame(NELoop, new TGLayoutHints(kLHintsLeft |
					       kLHintsTop,
					       2,2,2,2));

   
   gClient->GetColorByName("#ffffff",ucolor);

   // combo box
   CBReaccion = new TGComboBox(HFFile,-1,kHorizontalFrame |
			       kSunkenFrame |
			       kOwnBackground);
   CBReaccion->AddEntry("lambda, Kaon+",0);
   CBReaccion->AddEntry("prot\363n, pi0",1);
   CBReaccion->AddEntry("neutr\363n, pi+",2);
   CBReaccion->Connect("Selected(Int_t)","WMainProceso",this,"Reaction(Int_t)");
   CBReaccion->Select(0);
   CBReaccion->SetEnabled(true);
   CBReaccion->Resize(104,25);
   HFFile->AddFrame(CBReaccion, new TGLayoutHints(kLHintsRight |
						  kLHintsTop,
						  2,2,2,2));
   LReaccion = new TGLabel(HFFile,"Reacci\363n");
   LReaccion->SetTextJustify(36);
   LReaccion->SetMargins(0,0,0,0);
   LReaccion->SetWrapLength(-1);
   HFFile->AddFrame(LReaccion, new TGLayoutHints(kLHintsRight |
						 kLHintsTop,
						 2,2,2,2));

   GFDatos->AddFrame(HFFile, new TGLayoutHints(kLHintsLeft |
					       kLHintsTop |
					       kLHintsExpandX,
					       2,2,2,2));

   //::::::Marco para la variable S de Mandelstam:::::::::::::::::://
   HFVS = new TGHorizontalFrame(GFDatos,437,29,
				kHorizontalFrame);
   LVSLab = new TGLabel(HFVS,"Variable S_Lab");
   LVSLab->SetTextJustify(36);
   LVSLab->SetMargins(0,0,0,0);
   LVSLab->SetWrapLength(-1);
   HFVS->AddFrame(LVSLab, new TGLayoutHints(kLHintsLeft |
					    kLHintsTop |
					    kLHintsCenterY,
					    2,2,2,2));
   NEVSLab = new TGNumberEntry(HFVS, (Double_t) 0,8,-1,
			       (TGNumberFormat::EStyle) 5);
   NEVSLab->SetName("NEVSLab");
   NEVSLab->SetState(kFALSE);
   HFVS->AddFrame(NEVSLab, new TGLayoutHints(kLHintsLeft |
					     kLHintsTop,
					     2,2,2,2));
   NEVSCM = new TGNumberEntry(HFVS, (Double_t) 0,8,-1,
			      (TGNumberFormat::EStyle) 5);
   NEVSCM->SetName("NEVSCM");
   NEVSCM->SetState(kFALSE);
   HFVS->AddFrame(NEVSCM, new TGLayoutHints(kLHintsRight |
					    kLHintsTop,
					    2,2,2,2));
   LVSCM = new TGLabel(HFVS,"Variable S_CM");
   LVSCM->SetTextJustify(36);
   LVSCM->SetMargins(0,0,0,0);
   LVSCM->SetWrapLength(-1);
   HFVS->AddFrame(LVSCM, new TGLayoutHints(kLHintsRight |
					   kLHintsTop |
					   kLHintsCenterY,
					   2,2,2,2));

   GFDatos->AddFrame(HFVS, new TGLayoutHints(kLHintsLeft |
					     kLHintsTop |
					     kLHintsExpandX,
					     2,2,2,2));

   //::::::::Marco para la variable T de Mandelstam::::::::::://
   HFVT = new TGHorizontalFrame(GFDatos,437,29,
				kHorizontalFrame);
   LVTLab = new TGLabel(HFVT,"Variable T_Lab");
   LVTLab->SetTextJustify(36);
   LVTLab->SetMargins(0,0,0,0);
   LVTLab->SetWrapLength(-1);
   HFVT->AddFrame(LVTLab, new TGLayoutHints(kLHintsLeft |
					    kLHintsTop |
					    kLHintsCenterY,
					    2,2,2,2));
   NEVTLab = new TGNumberEntry(HFVT, (Double_t) 0,8,-1,
			       (TGNumberFormat::EStyle) 5);
   NEVTLab->SetName("NEVTLab");
   NEVTLab->SetState(kFALSE);
   HFVT->AddFrame(NEVTLab, new TGLayoutHints(kLHintsLeft |
					     kLHintsTop,
					     2,2,2,2));
   NEVTCM = new TGNumberEntry(HFVT, (Double_t) 0,8,-1,
			      (TGNumberFormat::EStyle) 5);
   NEVTCM->SetName("NETSCM");
   NEVTCM->SetState(kFALSE);
   HFVT->AddFrame(NEVTCM, new TGLayoutHints(kLHintsRight |
					    kLHintsTop,
					    2,2,2,2));
   LVTCM = new TGLabel(HFVT,"Variable T_CM");
   LVTCM->SetTextJustify(36);
   LVTCM->SetMargins(0,0,0,0);
   LVTCM->SetWrapLength(-1);
   HFVT->AddFrame(LVTCM, new TGLayoutHints(kLHintsRight |
					   kLHintsTop |
					   kLHintsCenterY,
					   2,2,2,2));

   GFDatos->AddFrame(HFVT, new TGLayoutHints(kLHintsLeft |
					     kLHintsTop |
					     kLHintsExpandX,
					     2,2,2,2));

   //::::::Marco para la variable U de Mandelstam:::::::::::::://
   HFVU = new TGHorizontalFrame(GFDatos,437,29,
				kHorizontalFrame);
   LVULab = new TGLabel(HFVU,"Variable U_Lab");
   LVULab->SetTextJustify(36);
   LVULab->SetMargins(0,0,0,0);
   LVULab->SetWrapLength(-1);
   HFVU->AddFrame(LVULab, new TGLayoutHints(kLHintsLeft |
					    kLHintsTop |
					    kLHintsCenterY,
					    2,2,2,2));
   NEVULab = new TGNumberEntry(HFVU, (Double_t) 0,8,-1,
			       (TGNumberFormat::EStyle) 5);
   NEVULab->SetName("NEVULab");
   NEVULab->SetState(kFALSE);
   HFVU->AddFrame(NEVULab, new TGLayoutHints(kLHintsLeft |
					     kLHintsTop,
					     2,2,2,2));
   NEVUCM = new TGNumberEntry(HFVU, (Double_t) 0,8,-1,
			      (TGNumberFormat::EStyle) 5);
   NEVUCM->SetName("NEVUCM");
   NEVUCM->SetState(kFALSE);
   HFVU->AddFrame(NEVUCM, new TGLayoutHints(kLHintsRight |
					    kLHintsTop,2,2,2,2));
   LVUCM = new TGLabel(HFVU,"Variable U_CM");
   LVUCM->SetTextJustify(36);
   LVUCM->SetMargins(0,0,0,0);
   LVUCM->SetWrapLength(-1);
   HFVU->AddFrame(LVUCM, new TGLayoutHints(kLHintsRight |
					   kLHintsTop |
					   kLHintsCenterY,
					   2,2,2,2));

   GFDatos->AddFrame(HFVU, new TGLayoutHints(kLHintsLeft |
					     kLHintsTop |
					     kLHintsExpandX,
					     2,2,2,2));

   //:::::::Dibujar vectores y guardar datos:::::::::::::::::::::::::://
   HFSave = new TGHorizontalFrame(GFDatos,437,29,
				  kHorizontalFrame);
   CHBVectors = new TGCheckButton(HFSave,"Vec. momento");
   CHBVectors->SetTextJustify(36);
   CHBVectors->SetMargins(0,0,0,0);
   CHBVectors->SetWrapLength(-1);
   HFSave->AddFrame(CHBVectors, new TGLayoutHints(kLHintsLeft |
						  kLHintsTop,
						  2,2,2,2));
   CHBVectors->SetDown(kTRUE);
   
   ufont = gClient->GetFont("-*-helvetica-medium-r-*-*-12-*-*-*-*-*-iso8859-1");

   
   // graphics context changes
   
   vale.fMask = kGCForeground |
     kGCBackground |
     kGCFillStyle |
     kGCFont |
     kGCGraphicsExposures;

   gClient->GetColorByName("#000000",vale.fForeground);
   gClient->GetColorByName("#e8e8e8",vale.fBackground);
   vale.fFillStyle = kFillSolid;
   vale.fFont = ufont->GetFontHandle();
   vale.fGraphicsExposures = kFALSE;
   uGC = gClient->GetGC(&vale, kTRUE);
   TESave = new TGTextEntry(HFSave, new TGTextBuffer(14),
			    -1,uGC->GetGC(),
			    ufont->GetFontStruct(),
			    kSunkenFrame | kOwnBackground);
   TESave->SetName("TESave");
   TESave->SetMaxLength(4096);
   TESave->SetAlignment(kTextLeft);
   TESave->SetText("");   
   TESave->Resize(144,TESave->GetDefaultHeight());
   TESave->SetEnabled(false);
   HFSave->AddFrame(TESave, new TGLayoutHints(kLHintsRight |
					      kLHintsTop,
					      2,2,2,2));
   CHBSave = new TGCheckButton(HFSave,"Guardar");
   CHBSave->SetTextJustify(36);
   CHBSave->SetMargins(0,0,0,0);
   CHBSave->SetWrapLength(-1);
   HFSave->AddFrame(CHBSave, new TGLayoutHints(kLHintsRight |
					       kLHintsTop,
					       2,2,2,2));
   CHBSave->Connect("Clicked()","WMainProceso",this,"BSave()");
   GFDatos->AddFrame(HFSave, new TGLayoutHints(kLHintsLeft |
					       kLHintsTop |
					       kLHintsExpandX,
					       2,2,2,2));

   //:::::::::::::::Abrir ventana de ayuda:::::::::::::::::::::::::::://
   HFHelp = new TGHorizontalFrame(GFDatos,437,29,
				  kHorizontalFrame);
   BHelp = new TGTextButton(HFHelp,"&Ayuda",-1,
			    TGTextButton::GetDefaultGC()(),
			    TGTextButton::GetDefaultFontStruct(),
			    kRaisedFrame);
   BHelp->SetTextJustify(36);
   BHelp->SetMargins(0,0,0,0);
   BHelp->SetWrapLength(-1);
   BHelp->Resize(43,25);
   BHelp->Connect("Clicked()","WMainProceso",this,"Help()");
   HFHelp->AddFrame(BHelp, new TGLayoutHints(kLHintsLeft |
					     kLHintsCenterX |
					     kLHintsTop,
					     2,2,2,2));
   GFDatos->AddFrame(HFHelp, new TGLayoutHints(kLHintsLeft |
					       kLHintsBottom |
					       kLHintsExpandX,
					       2,2,2,2));

   GFDatos->SetLayoutManager(new TGVerticalLayout(GFDatos));
   GFDatos->Resize(479,370);
   VFControl->AddFrame(GFDatos, new TGLayoutHints(kLHintsLeft |
						  kLHintsTop |
						  kLHintsExpandX |
						  kLHintsExpandY,
						  2,2,2,2));

   HFViews->AddFrame(VFControl, new TGLayoutHints(kLHintsLeft |
						  kLHintsTop |
						  kLHintsExpandX |
						  kLHintsExpandY,
						  2,2,2,2));

   // vertical frame
   VFGraf = new TGVerticalFrame(HFViews,486,550,
				kVerticalFrame |
				kRaisedFrame);
   VFGraf->SetName("VFGraf");

   // vertical frame
   VFGrafLab = new TGVerticalFrame(VFGraf,480,364,
				   kVerticalFrame);
   VFGrafLab->SetName("VFGrafLab");
   LGrafLab = new TGLabel(VFGrafLab,"Gr\341ficas Laboratorio");
   LGrafLab->SetTextJustify(36);
   LGrafLab->SetMargins(0,0,0,0);
   LGrafLab->SetWrapLength(-1);
   VFGrafLab->AddFrame(LGrafLab, new TGLayoutHints(kLHintsLeft |
						   kLHintsTop |
						   kLHintsExpandX,
						   2,2,2,2));

   // tab widget
   Tab1Lab = new TGTab(VFGrafLab,476,332);

   // container of "Tab1"
   //CFLab1;
   CFLab1 = Tab1Lab->AddTab("V. S_Lab i");
   CFLab1->SetLayoutManager(new TGVerticalLayout(CFLab1));
   // embedded canvas
   ECLab1 = new TRootEmbeddedCanvas(0,CFLab1,468,300,
				    kSunkenFrame);
   wECLab1 = ECLab1->GetCanvasWindowId();
   CGrafLab1 = new TCanvas("CGrafLab1", 10, 10, wECLab1);
   ECLab1->AdoptCanvas(CGrafLab1);
   CFLab1->AddFrame(ECLab1, new TGLayoutHints(kLHintsLeft |
					      kLHintsTop |
					      kLHintsExpandX |
					      kLHintsExpandY,
					      2,2,2,2));


   // container of "Tab2"
   
   CFLab2 = Tab1Lab->AddTab("V. T_Lab i");
   CFLab2->SetLayoutManager(new TGVerticalLayout(CFLab2));
   // embedded canvas
   ECLab2 = new TRootEmbeddedCanvas(0,CFLab2,468,300,
				    kSunkenFrame);
   wECLab2 = ECLab2->GetCanvasWindowId();
   CGrafLab2 = new TCanvas("CGrafLab2", 10, 10, wECLab2);
   ECLab2->AdoptCanvas(CGrafLab2);
   CFLab2->AddFrame(ECLab2, new TGLayoutHints(kLHintsLeft |
					      kLHintsTop |
					      kLHintsExpandX |
					      kLHintsExpandY,
					      2,2,2,2));

   // container of "Tab3"   
   CFLab3 = Tab1Lab->AddTab("V. U_Lab i");
   CFLab3->SetLayoutManager(new TGVerticalLayout(CFLab3));
   // embedded canvas
   ECLab3 = new TRootEmbeddedCanvas(0,CFLab3,468,300,
				    kSunkenFrame);
   wECLab3 = ECLab3->GetCanvasWindowId();
   CGrafLab3 = new TCanvas("CGrafLab3", 10, 10, wECLab3);
   ECLab3->AdoptCanvas(CGrafLab3);
   CFLab3->AddFrame(ECLab3, new TGLayoutHints(kLHintsLeft |
					      kLHintsTop |
					      kLHintsExpandX |
					      kLHintsExpandY,
					      2,2,2,2));

   // container of "Tab4"   
   CFLab4 = Tab1Lab->AddTab("cos(th) M.");
   CFLab4->SetLayoutManager(new TGVerticalLayout(CFLab4));
   // embedded canvas
   ECLab4 = new TRootEmbeddedCanvas(0,CFLab4,468,300,kSunkenFrame);
   wECLab4 = ECLab4->GetCanvasWindowId();
   CGrafLab4 = new TCanvas("CGrafLab4", 10, 10, wECLab4);
   ECLab4->AdoptCanvas(CGrafLab4);
   CFLab4->AddFrame(ECLab4, new TGLayoutHints(kLHintsLeft |
					      kLHintsTop |
					      kLHintsExpandX |
					      kLHintsExpandY,
					      2,2,2,2));

   // container of "Tab5"   
   CFLab5 = Tab1Lab->AddTab("cos(th) B.");
   CFLab5->SetLayoutManager(new TGVerticalLayout(CFLab5));
   // embedded canvas
   ECLab5 = new TRootEmbeddedCanvas(0,CFLab5,468,300,
				    kSunkenFrame);
   wECLab5 = ECLab5->GetCanvasWindowId();
   CGrafLab5 = new TCanvas("CGrafLab5", 10, 10, wECLab5);
   ECLab5->AdoptCanvas(CGrafLab5);
   CFLab5->AddFrame(ECLab5, new TGLayoutHints(kLHintsLeft |
					      kLHintsTop |
					      kLHintsExpandX |
					      kLHintsExpandY,
					      2,2,2,2));

// container of "Tab6"   
   CFLab6 = Tab1Lab->AddTab("E.M.B.");
   CFLab6->SetLayoutManager(new TGVerticalLayout(CFLab6));
   // embedded canvas
   ECLab6 = new TRootEmbeddedCanvas(0,CFLab6,468,300,
				    kSunkenFrame);
   wECLab6 = ECLab6->GetCanvasWindowId();
   CGrafLab6 = new TCanvas("CGrafLab5", 10, 10, wECLab6);
   ECLab6->AdoptCanvas(CGrafLab6);
   CFLab6->AddFrame(ECLab6, new TGLayoutHints(kLHintsLeft |
					      kLHintsTop |
					      kLHintsExpandX |
					      kLHintsExpandY,
					      2,2,2,2));
   
   // container of "Tab7"   
   CFLab7 = Tab1Lab->AddTab("E.M.M.");
   CFLab7->SetLayoutManager(new TGVerticalLayout(CFLab7));
   // embedded canvas
   ECLab7 = new TRootEmbeddedCanvas(0,CFLab7,468,300,
				    kSunkenFrame);
   wECLab7 = ECLab7->GetCanvasWindowId();
   CGrafLab7 = new TCanvas("CGrafLab7", 10, 10, wECLab7);
   ECLab7->AdoptCanvas(CGrafLab7);
   CFLab7->AddFrame(ECLab7, new TGLayoutHints(kLHintsLeft |
					      kLHintsTop |
					      kLHintsExpandX |
					      kLHintsExpandY,
					      2,2,2,2));

   
   Tab1Lab->SetTab(1);

   Tab1Lab->Resize(Tab1Lab->GetDefaultSize());
   VFGrafLab->AddFrame(Tab1Lab, new TGLayoutHints(kLHintsLeft |
						  kLHintsTop |
						  kLHintsExpandX |
						  kLHintsExpandY,
						  2,2,2,2));

   VFGraf->AddFrame(VFGrafLab, new TGLayoutHints(kLHintsLeft |
						 kLHintsTop |
						 kLHintsExpandX |
						 kLHintsExpandY,
						 2,2,2,2));
   HLGraf = new TGHorizontal3DLine(VFGraf,480,8);
   HLGraf->SetName("HLGraf");
   VFGraf->AddFrame(HLGraf, new TGLayoutHints(kLHintsLeft |
					      kLHintsTop |
					      kLHintsExpandX,
					      2,2,2,2));

   // vertical frame CM
   VFGrafCM = new TGVerticalFrame(VFGraf,480,364,
				  kVerticalFrame);
   VFGrafCM->SetName("VFGrafCM");
   LGrafCM = new TGLabel(VFGrafCM,"Gr\341ficas Centro de masa");
   LGrafCM->SetTextJustify(36);
   LGrafCM->SetMargins(0,0,0,0);
   LGrafCM->SetWrapLength(-1);
   VFGrafCM->AddFrame(LGrafCM, new TGLayoutHints(kLHintsLeft |
						 kLHintsTop |
						 kLHintsExpandX,
						 2,2,2,2));

   // tab widget
   Tab1CM = new TGTab(VFGrafCM,476,237);

   // container of "Tab1"
   //CFCM1;
   CFCM1 = Tab1CM->AddTab("V. S_CM i");
   CFCM1->SetLayoutManager(new TGVerticalLayout(CFCM1));
   // embedded canvas
   ECGrafCM1 = new TRootEmbeddedCanvas(0,CFCM1,468,305,
				       kSunkenFrame);
   wECGrafCM1 = ECGrafCM1->GetCanvasWindowId();
   CGrafCM1 = new TCanvas("CGrafCM1", 10, 10, wECGrafCM1);
   ECGrafCM1->AdoptCanvas(CGrafCM1);
   CFCM1->AddFrame(ECGrafCM1, new TGLayoutHints(kLHintsLeft |
						kLHintsTop |
						kLHintsExpandX |
						kLHintsExpandY,
						2,2,2,2));


   // container of "Tab2"
   //CFCM2;
   CFCM2 = Tab1CM->AddTab("V. T_CM  i");
   CFCM2->SetLayoutManager(new TGVerticalLayout(CFCM2));
   // embedded canvas
   ECCM2 = new TRootEmbeddedCanvas(0,CFCM2,468,305,
				   kSunkenFrame);
   wECCM2 = ECCM2->GetCanvasWindowId();
   CCM2 = new TCanvas("CCM2", 10, 10, wECCM2);
   ECCM2->AdoptCanvas(CCM2);
   CFCM2->AddFrame(ECCM2, new TGLayoutHints(kLHintsLeft |
					    kLHintsTop |
					    kLHintsExpandX |
					    kLHintsExpandY,
					    2,2,2,2));

   // container of "Tab3"
   //CFCM3;
   CFCM3 = Tab1CM->AddTab("V. U_CM i");
   CFCM3->SetLayoutManager(new TGVerticalLayout(CFCM3));
   // embedded canvas
   ECCM3 = new TRootEmbeddedCanvas(0,CFCM3,468,305,
				   kSunkenFrame);
   wECCM3 = ECCM3->GetCanvasWindowId();
   CCM3 = new TCanvas("CCM3", 10, 10, wECCM3);
   ECCM3->AdoptCanvas(CCM3);
   CFCM3->AddFrame(ECCM3, new TGLayoutHints(kLHintsLeft |
					    kLHintsTop |
					    kLHintsExpandX |
					    kLHintsExpandY,
					    2,2,2,2));

   // container of "Tab4"
   //CFCM4;
   CFCM4 = Tab1CM->AddTab("cos(th)M.L.");
   CFCM4->SetLayoutManager(new TGVerticalLayout(CFCM4));
   // embedded canvas
   ECCM4 = new TRootEmbeddedCanvas(0,CFCM4,468,305,
				   kSunkenFrame);
   wECCM4 = ECCM4->GetCanvasWindowId();
   CCM4 = new TCanvas("CCM4", 10, 10, wECCM4);
   ECCM4->AdoptCanvas(CCM4);
   CFCM4->AddFrame(ECCM4, new TGLayoutHints(kLHintsLeft |
					    kLHintsTop |
					    kLHintsExpandX |
					    kLHintsExpandY,
					    2,2,2,2));

   // container of "Tab5"
   //CFCM5;
   CFCM5 = Tab1CM->AddTab("cos(th)B.L.");
   CFCM5->SetLayoutManager(new TGVerticalLayout(CFCM5));
   // embedded canvas
   ECCM5 = new TRootEmbeddedCanvas(0,CFCM5,468,305,
				   kSunkenFrame);
   wECCM5 = ECCM5->GetCanvasWindowId();
   CCM5 = new TCanvas("CCM5", 10, 10, wECCM5);
   ECCM5->AdoptCanvas(CCM5);
   CFCM5->AddFrame(ECCM5, new TGLayoutHints(kLHintsLeft |
					    kLHintsTop |
					    kLHintsExpandX |
					    kLHintsExpandY,
					    2,2,2,2));

   // container of "Tab6"
   //CFCM6;
   CFCM6 = Tab1CM->AddTab("E.b.CM");
   CFCM6->SetLayoutManager(new TGVerticalLayout(CFCM6));
   // embedded canvas
   ECCM6 = new TRootEmbeddedCanvas(0,CFCM6,468,305,
				   kSunkenFrame);
   wECCM6 = ECCM6->GetCanvasWindowId();
   CCM6 = new TCanvas("CCM6", 10, 10, wECCM6);
   ECCM6->AdoptCanvas(CCM6);
   CFCM6->AddFrame(ECCM6, new TGLayoutHints(kLHintsLeft |
					    kLHintsTop |
					    kLHintsExpandX |
					    kLHintsExpandY,
					    2,2,2,2));

      //CFCM6;
   CFCM7 = Tab1CM->AddTab("E.t.CM");
   CFCM7->SetLayoutManager(new TGVerticalLayout(CFCM7));
   // embedded canvas
   ECCM7 = new TRootEmbeddedCanvas(0,CFCM7,468,305,
				   kSunkenFrame);
   wECCM7 = ECCM7->GetCanvasWindowId();
   CCM7 = new TCanvas("CCM7", 10, 10, wECCM7);
   ECCM7->AdoptCanvas(CCM7);
   CFCM7->AddFrame(ECCM7, new TGLayoutHints(kLHintsLeft |
					    kLHintsTop |
					    kLHintsExpandX |
					    kLHintsExpandY,
					    2,2,2,2));

   Tab1CM->SetTab(1);

   Tab1CM->Resize(Tab1CM->GetDefaultSize());
   VFGrafCM->AddFrame(Tab1CM, new TGLayoutHints(kLHintsLeft |
						kLHintsTop |
						kLHintsExpandX |
						kLHintsExpandY,
						2,2,2,2));

   VFGraf->AddFrame(VFGrafCM, new TGLayoutHints(kLHintsLeft |
						kLHintsTop |
						kLHintsExpandX |
						kLHintsExpandY,
						2,2,2,2));

   HFViews->AddFrame(VFGraf, new TGLayoutHints(kLHintsLeft |
					       kLHintsTop |
					       kLHintsExpandX |
					       kLHintsExpandY,
					       2,2,2,2));

   VFMain->AddFrame(HFViews, new TGLayoutHints(kLHintsLeft |
					       kLHintsTop |
					       kLHintsExpandX |
					       kLHintsExpandY,
					       2,2,2,2));

   // horizontal frame
   HFBut = new TGHorizontalFrame(VFMain,980,29,
				 kHorizontalFrame);
   HFBut->SetName("HFBut");
   BLimpiar = new TGTextButton(HFBut,"&Limpiar",-1,
			       TGTextButton::GetDefaultGC()(),
			       TGTextButton::GetDefaultFontStruct(),
			       kRaisedFrame);
   BLimpiar->SetTextJustify(36);
   BLimpiar->SetMargins(0,0,0,0);
   BLimpiar->SetWrapLength(-1);
   BLimpiar->SetEnabled(false);
   BLimpiar->Resize(49,25);
   HFBut->AddFrame(BLimpiar, new TGLayoutHints(kLHintsLeft |
					       kLHintsTop,
					       2,2,2,2));
   BLimpiar->Connect("Clicked()","WMainProceso",this,"Clean()");
   
   BPlay = new TGTextButton(HFBut,"&Simular",-1,
			    TGTextButton::GetDefaultGC()(),
			    TGTextButton::GetDefaultFontStruct(),
			    kRaisedFrame);
   BPlay->SetTextJustify(36);
   BPlay->SetMargins(0,0,0,0);
   BPlay->SetWrapLength(-1);
   BPlay->SetEnabled(true);
   BPlay->Resize(50,25);
   HFBut->AddFrame(BPlay, new TGLayoutHints(kLHintsLeft |
					    kLHintsCenterX |
					    kLHintsTop,
					    2,2,2,2));
   BPlay->Connect("Clicked()","WMainProceso",this,"Execution()");
   
   BSalir = new TGTextButton(HFBut,"&Salir",-1,
			     TGTextButton::GetDefaultGC()(),
			     TGTextButton::GetDefaultFontStruct(),
			     kRaisedFrame);
   BSalir->SetTextJustify(36);
   BSalir->SetMargins(0,0,0,0);
   BSalir->SetWrapLength(-1);
   BSalir->Resize(33,25);
   HFBut->AddFrame(BSalir, new TGLayoutHints(kLHintsRight |
					     kLHintsTop,
					     2,2,2,2));
   BSalir->Connect("Clicked()","WMainProceso",this,"Exit()");
   
   VFMain->AddFrame(HFBut, new TGLayoutHints(kLHintsLeft |
					     kLHintsBottom |
					     kLHintsExpandX,
					     2,2,2,2));

   MainFrame->AddFrame(VFMain, new TGLayoutHints(kLHintsExpandX |
						 kLHintsExpandY,
						 1,1,1,1));

   MainFrame->SetMWMHints(kMWMDecorAll,
                        kMWMFuncAll,
                        kMWMInputModeless);
   MainFrame->MapSubwindows();

   MainFrame->Resize(MainFrame->GetDefaultSize());
   MainFrame->MapWindow();
   MainFrame->Resize(986,700);
}  

WMainProceso::~WMainProceso(){}

void WMainProceso::DrawHist(){
  //-------------------
  CGrafLab1->cd();
  SLabi->Draw();         
  CGrafLab1->Update();
  CGrafLab1->Modified();
  //-------------------
  CGrafLab2->cd();  
  canalt1->Draw();  
  CGrafLab2->Update();
  CGrafLab2->Modified();
  
  //-------------------
  CGrafLab3->cd();    
  canalu1->Draw();
  CGrafLab3->Update();
  CGrafLab3->Modified();
  //-------------------
  CGrafLab4->cd();    
  dkcos->Draw();
  CGrafLab4->Update();
  CGrafLab4->Modified();
  //-------------------
  CGrafLab5->cd();    
  dldcos->Draw();
  CGrafLab5->Update();
  CGrafLab5->Modified();
  //-------------------
  CGrafLab6->cd();    
  enminld->Draw();
  CGrafLab6->Update();
  CGrafLab6->Modified();
  //-------------------
  CGrafLab7->cd();    
  enminkp->Draw();
  CGrafLab7->Update();
  CGrafLab7->Modified();
  //-------------------
  CGrafCM1->cd();    
  SCmi->Draw();   
  CGrafCM1->Update();
  CGrafCM1->Modified();
  //--------------------
  CCM2->cd();  
  canalt1cm->Draw();
  CCM2->Update();
  CCM2->Modified();
  //--------------------
  CCM3->cd();  
  canalu1cm->Draw();
  CCM3->Update();
  CCM3->Modified();
  //--------------------
  CCM4->cd();  
  dkcoscm->Draw();
  CCM4->Update();
  CCM4->Modified();
  //--------------------
  CCM5->cd();  
  dldcoscm->Draw();
  CCM5->Update();
  CCM5->Modified();
  //--------------------
  CCM6->cd();  
  Energiagcm->Draw();
  CCM6->Update();
  CCM6->Modified();
  //--------------------
  CCM7->cd();  
  Energiapcm->Draw();
  CCM7->Update();
  CCM7->Modified();
  //--------------------
}

void WMainProceso::move(){
  //::::::::::::::Inicializacion de tiempos::://
  talab=0;
  tdlab=0;
  tacm=0;
  tdcm=0;
  //::::::Construccion de elipses y flechas::::::://
  pllab=new TEllipse();
  fklab=new TEllipse();
  plcm=new TEllipse();
  fkcm=new TEllipse();
  apllab=new TArrow();
  afklab=new TArrow();
  aplcm=new TArrow();
  afkcm=new TArrow();

  //::::::::::::Inicializacion de posiciones::::::::://
  rkl.SetXYZ(0.0,0.0,0.0);
  rll.SetXYZ(0.0,0.0,0.0);
  rkcm.SetXYZ(0.0,0.0,0.0);
  rlcm.SetXYZ(0.0,0.0,0.0);
  
  

  
  while(((abs(rkcm.X())<=8)and(abs(rkcm.Y())<=8) )
	or((abs(rlcm.X())<=8) and (abs(rlcm.Y())<=8))
	or((abs(rkl.X())<=8) and(abs(rkl.Y())<=8) )
	or((abs(rll.X())<=8) and (abs(rll.Y())<=8))) {
    
    if(BLimpiar->IsEnabled()==false){
      break;
    }
    
    //-----------------
    rpl0.SetXYZ(0,0,0);  
    rpl.SetXYZ(rpl0.X()+(ppl.Z()*0.5)*talab,
	       rpl0.Y()+(ppl.Y()*0.5)*talab,0);
    pllab->SetR1(r);
    pllab->SetR2(r);    
    //-----------------
    
    //---------------------------
    rpcm0.SetXYZ(8-r,0,0);      
    rpcm.SetXYZ(rpcm0.X()+(pptcm.Z()*0.5)*tacm,
		rpcm0.Y()+(pptcm.Y()*0.5)*tacm,0);
    plcm->SetR1(r);
    plcm->SetR2(r);
    
    ///-----------------------
    rfl0.SetXYZ(-8+r,0,0);  
    rfl.SetXYZ(rfl0.X()+(pgl.Z()*0.5)*talab,0,0);    
    fklab->SetR1(r);
    fklab->SetR2(r);    
    //-----------------------
    
    //--------------------------
    rfcm0.SetXYZ(-8+r,0,0);  
    rfcm.SetXYZ(rfcm0.X()+(pbcm.Z()*0.5)*tacm,0,0);    
    fkcm->SetR1(r);
    fkcm->SetR2(r);
    //--------------------------
    
    //---------------------------
    rkl0.SetXYZ(0,0,0);  
    rkl.SetXYZ(rkl0.X()+(pkpl.Z()*0.5)*tdlab,
	       rkl0.Y()+(pkpl.Y()*0.5)*tdlab,0);    
    //-------------------------
    rkcm0.SetXYZ(0,0,0);  
    rkcm.SetXYZ(rkcm0.X()+(pkpcm.Z()*0.5)*tdcm,
		rkcm0.Y()+(pkpcm.Y()*0.5)*tdcm,0);    

    //-----------------
    //-----------------
    rll0.SetXYZ(0,0,0);  
    rll.SetXYZ(rll0.X()+(pldl.Z()*0.5)*tdlab,
	       rll0.Y()+(pldl.Y()*0.5)*tdlab,0);
    //------------------
    rlcm0.SetXYZ(0,0,0);  
    rlcm.SetXYZ(rlcm0.X()+(pldcm.Z()*0.5)*tdcm,
		rlcm0.Y()+(pldcm.Y()*0.5)*tdlab,0);
    //--------------
    
    //-------Antes del choque Lab-------//
    if(rfl.X()<rpl.X()){
      gSystem->ProcessEvents();
      pllab->SetX1(rpl.X());
      pllab->SetY1(0);
      pllab->SetFillColor(kGreen);
      fklab->SetX1(rfl.X());
      fklab->SetY1(0.0);
      fklab->SetFillColor(kBlue);
      //----------------------------------//
      if(CHBVectors->IsDown()==true){      
	apllab->SetX1(rpl.X());
	apllab->SetX2(rpl.X()+(ppl.Z()*50)*dtlab);
	apllab->SetY1(rpl.Y());
	apllab->SetY2(rpl.Y()+(ppl.Y()*50)*dtlab);
	apllab->SetLineColor(kGreen);
	apllab->SetFillColor(kGreen);

	afklab->SetX1(rfl.X());
	afklab->SetX2(rfl.X()+(pgl.Z()*50)*dtlab);
	afklab->SetY1(rfl.Y());
	afklab->SetY2(rfl.Y()+(pgl.Y()*50)*dtlab);
	afklab->SetLineColor(kBlue);
	afklab->SetFillColor(kBlue);

	afklab->SetArrowSize(0.05);
	apllab->SetArrowSize(0.05);
	
      }
      //-----------------------------------------//
      else if(CHBVectors->IsDown()==false){
	
	apllab->SetX1(rpl.X());
	apllab->SetX2(rpl.X());
	apllab->SetY1(rpl.Y());
	apllab->SetY2(rpl.Y());

	afklab->SetX1(rfl.X());
	afklab->SetX2(rfl.X());
	afklab->SetY1(rfl.Y());
	afklab->SetY2(rfl.Y());

	afklab->SetArrowSize(0.0);
	apllab->SetArrowSize(0.0);
	
      }
      tdlab=0;
    }
    //----Antes del choque CM------------//
    if(rfcm.X()<rpcm.X()){
      gSystem->ProcessEvents();
      plcm->SetX1(rpcm.X());
      plcm->SetY1(rpcm.Y());
      plcm->SetFillColor(kGreen);
      fkcm->SetX1(rfcm.X());
      fkcm->SetY1(rfcm.Y());
      fkcm->SetFillColor(kBlue);
      //----------------------------------//
      if(CHBVectors->IsDown()==true){
	aplcm->SetX1(rpcm.X());
	aplcm->SetX2(rpcm.X()+(pptcm.Z()*50)*dtcm);
	aplcm->SetY1(rpcm.Y());
	aplcm->SetY2(rpcm.Y()+(pptcm.Y()*50)*dtcm);
	aplcm->SetLineColor(kGreen);
	aplcm->SetFillColor(kGreen);

	afkcm->SetX1(rfcm.X());
	afkcm->SetX2(rfcm.X()+(pbcm.Z()*50)*dtcm);
	afkcm->SetY1(rfcm.Y());
	afkcm->SetY2(rfcm.Y()+(pbcm.Y()*50)*dtcm);
	afkcm->SetLineColor(kBlue);
	afkcm->SetFillColor(kBlue);

	afkcm->SetArrowSize(0.05);
	aplcm->SetArrowSize(0.05);	
      }
      //------------------------------------//
      else if(CHBVectors->IsDown()==false){    
	aplcm->SetX1(rpcm.X());
	aplcm->SetX2(rpcm.X());
	aplcm->SetY1(rpcm.Y());
	aplcm->SetY2(rpcm.Y());

	afkcm->SetX1(rfcm.X());
	afkcm->SetX2(rfcm.X());
	afkcm->SetY1(rfcm.Y());
	afkcm->SetY2(rfcm.Y());     

	afkcm->SetArrowSize(0.0);
	aplcm->SetArrowSize(0.0);
      }
      //_----------------------------------//            
      tdcm=0;
    }
    //::::::::::::::Despues del choque en Lab:::::::::::::::::::::::://
    if(rfl.X()>=rpl.X()){
      gSystem->ProcessEvents();
      fklab->SetX1(rkl.X());
      fklab->SetY1(rkl.Y());
      fklab->SetFillColor(kRed);
      pllab->SetX1(rll.X());
      pllab->SetY1(rll.Y());
      pllab->SetFillColor(kYellow);
      //----------------------------------------//
      if(CHBVectors->IsDown()==true){
	afklab->SetX1(rkl.X());
	afklab->SetX2(rkl.X()+(pkpl.Z()*50)*dtlab);
	afklab->SetY1(rkl.Y());
	afklab->SetY2(rkl.Y()+(pkpl.Y()*50)*dtlab);
	afklab->SetLineColor(kRed);
	afklab->SetFillColor(kRed);

	apllab->SetX1(rll.X());
	apllab->SetX2(rll.X()+(pldl.Z()*50)*dtlab);
	apllab->SetY1(rll.Y());
	apllab->SetY2(rll.Y()+(pldl.Y()*50)*dtlab);
	apllab->SetLineColor(kYellow);
	apllab->SetFillColor(kYellow);

	afklab->SetArrowSize(0.05);
	apllab->SetArrowSize(0.05);
      }
      else if(CHBVectors->IsDown()==false){
	afklab->SetX1(rkl.X());
	afklab->SetX2(rkl.X());
	afklab->SetY1(rkl.Y());
	afklab->SetY2(rkl.Y());

	apllab->SetX1(rll.X());
	apllab->SetX2(rll.X());
	apllab->SetY1(rll.Y());
	apllab->SetY2(rll.Y());

	afklab->SetArrowSize(0.0);
	apllab->SetArrowSize(0.0);

      }
    }
    //::::::::::::::::Despues del choque en CM::::::::::::://
    if(rfcm.X()>=rpcm.X()){
      fkcm->SetX1(rkcm.X());
      fkcm->SetY1(rkcm.Y());
      fkcm->SetFillColor(kRed);
      plcm->SetX1(rlcm.X());
      plcm->SetY1(rlcm.Y());
      plcm->SetFillColor(kYellow);
      
      if(CHBVectors->IsDown()==true){
	aplcm->SetX1(rlcm.X());
	aplcm->SetX2(rlcm.X()+(pldcm.Z()*50)*dtcm);
	aplcm->SetY1(rlcm.Y());
	aplcm->SetY2(rlcm.Y()+(pldcm.Y()*50)*dtcm);
	aplcm->SetLineColor(kYellow);
	aplcm->SetFillColor(kYellow);

	afkcm->SetX1(rkcm.X());
	afkcm->SetX2(rkcm.X()+(pkpcm.Z()*50)*dtcm);
	afkcm->SetY1(rkcm.Y());
	afkcm->SetY2(rkcm.Y()+(pkpcm.Y()*50)*dtcm);
	afkcm->SetLineColor(kRed);
	afkcm->SetFillColor(kRed);

	afkcm->SetArrowSize(0.05);
	aplcm->SetArrowSize(0.05);
	
      }
      else if(CHBVectors->IsDown()==false){    
	aplcm->SetX1(rlcm.X());
	aplcm->SetX2(rlcm.X());
	aplcm->SetY1(rlcm.Y());
	aplcm->SetY2(rlcm.Y());
	afkcm->SetX1(rkcm.X());
	afkcm->SetX2(rkcm.X());
	afkcm->SetY1(rkcm.Y());
	afkcm->SetY2(rkcm.Y());     
	afkcm->SetArrowSize(0.0);
	aplcm->SetArrowSize(0.0);
      }
    }
    
    CLab->cd();
    fklab->Draw();
    pllab->Draw();    
    afklab->Draw("|>");
    apllab->Draw("|>");
    CLab->Update();
    
    
    CCM->cd();
    fkcm->Draw();
    plcm->Draw();    
    afkcm->Draw("|>");
    aplcm->Draw("|>");
    CCM->Update();
    
    
    talab=talab+dtlab;
    tdlab=tdlab+dtlab;
    tacm=tacm+dtcm;
    tdcm=tdcm+dtcm;

    
    
  }

  delete fklab;
  delete pllab;
  delete fkcm;
  delete plcm;
  delete afklab;
  delete apllab;
  delete afkcm;
  delete aplcm;
}

//---------------------Final de move()


void WMainProceso::Enable(){
  BPlay->SetEnabled(true);  
  CHBSave->SetEnabled(true);
  CBReaccion->SetEnabled(true);
  NENE->SetState(true);
  NEEnFo->SetState(true);
  NELoop->SetState(true);
}

void WMainProceso::Disable(){
  
  BPlay->SetEnabled(false);  
  TESave->SetEnabled(false);
  CBReaccion->SetEnabled(false);
  CHBSave->SetEnabled(false);
  NENE->SetState(false);
  NEEnFo->SetState(false);
  NELoop->SetState(false);
}



//----Boton de limpiar
void WMainProceso::Clean(){
  NEEnFo->SetNumber(0.0);
  NENE->SetNumber(0.0);
  NELoop->SetNumber(1);
  NEEn->SetNumber(0.0);
  NEVSLab->SetNumber(0.0);
  NEVTLab->SetNumber(0.0);
  NEVULab->SetNumber(0.0);
  NEVSCM->SetNumber(0.0);
  NEVTCM->SetNumber(0.0);
  NEVUCM->SetNumber(0.0);
  TESave->SetText(NULL);
  CHBSave->SetDown(false);
  EG=0.0;
  loop=1;
  NEVENT=0;
 
  
  
  CGrafLab1->Clear();
  CGrafLab1->Update();
  
  
  CGrafLab2->Clear();
  CGrafLab2->Update();

  
  CGrafLab3->Clear();
  CGrafLab3->Update();

  CGrafLab4->Clear();
  CGrafLab4->Update();
  
  
  CGrafLab5->Clear();
  CGrafLab5->Update();

  CGrafLab6->Clear();
  CGrafLab6->Update();

  CGrafLab7->Clear();
  CGrafLab7->Update();
  
  CGrafCM1->Clear();
  CGrafCM1->Update();
  
  
  CCM2->Clear();
  CCM2->Update();

  
  CCM3->Clear();
  CCM3->Update();

  CCM4->Clear();
  CCM4->Update();

  
  CCM5->Clear();
  CCM5->Update();

  CCM6->Clear();
  CCM6->Update();

  
  CCM7->Clear();
  CCM7->Update();

  
  
  CLab->Clear();
  CLab->Update();
  talab=0.0;
  tdlab=0.0;
  
  
  
  CCM->Clear();
  CCM->Update();
  tacm=0.0;
  tdcm=0.0;

  Enable();
  BLimpiar->SetEnabled(false);
}

//:::::::::::Boton de guardar:::::::::::://
void WMainProceso::BSave(){
  if(CHBSave->IsOn()==false){
    CHBSave->SetDown(false);
    TESave->SetEnabled(false);
  }
  if(CHBSave->IsOn()==true){
    CHBSave->SetDown(true);
    TESave->SetEnabled(true);
                 
  }
}
//--------------------------------------------------------------//
//---------Poniendo nombres y titulos a los histogramas---------//
void WMainProceso::Reaction(Int_t Opt){
  
  if(Opt==0){Mbarion=ML; Mmeson=MK;

  }
  else if(Opt==1){ Mbarion=MP; Mmeson=MPI0;
    
  }
  else if(Opt==2){ Mbarion=MN; Mmeson=MPIP;}
}

void  WMainProceso::booking(){

  //Declaracion de directorios
  Kaon = new TDirectoryFile("Meson","Meson");  
  Lambda = new TDirectoryFile("Barion","Barion");  	 
  Invariantes = new TDirectoryFile("Invariantes","Invariantes");
  Comparasiones = new TDirectoryFile("Comparaciones","Comparaciones");

   
  Kaon->cd();
  Kaon->SetNameTitle("Kaon","Kaon");
  //Laboratorio
  masak = new TH1F("masak","Masa del K^{+}", 50, (MK-0.001), (MK+0.001)); 
  masak->GetXaxis()->SetTitle("Masa del K^{+}");
  masak->GetYaxis()->SetTitle("Frecuencia");
  masak->GetXaxis()->CenterTitle();
  masak->GetYaxis()->CenterTitle();
  masak->SetLineColor(4);
  dkteta = new TH1F("dkteta","Distribuci#acute{o}n del #acute{a}ngulo #theta del K^{+}",200, 0, 180);
  dkteta->GetXaxis()->SetTitle("#acute{A}ngulo #theta");
  dkteta->GetYaxis()->SetTitle("Frecuencia");
  dkteta->GetXaxis()->CenterTitle();
  dkteta->GetYaxis()->CenterTitle();
  dkteta->SetLineColor(4);

  dkcos = new TH1F("Dkcos","Distribuci#acute{o}n del cos(#theta) del K^{+}",1000, -1, 1);
  dkcos->GetXaxis()->SetTitle("cos(#theta)");
  dkcos->GetYaxis()->SetTitle("Frecuencia");
  dkcos->GetXaxis()->CenterTitle();
  dkcos->GetYaxis()->CenterTitle();
  dkcos->SetLineColor(4);

  dkphi = new TH1F("Dkphi","Distribuci#acute{o}n del #acute{a}ngulo #phi del K^{+}",1000,-180,180);  
  dkphi->GetXaxis()->SetTitle("#acute{A}ngulo #Phi");
  dkphi->GetYaxis()->SetTitle("Frecuencia");
  dkphi->GetXaxis()->CenterTitle();
  dkphi->GetYaxis()->CenterTitle();
  dkphi->SetLineColor(4);

  PxC = new TH1F("Pxc","Momentum en x del K^{+}",500,-5,5);	
  PxC->GetXaxis()->SetTitle("Momentum en x");
  PxC->GetYaxis()->SetTitle("Frecuencia");
  PxC->GetXaxis()->CenterTitle();
  PxC->GetYaxis()->CenterTitle();
  PxC->SetLineColor(4);
  PyC = new TH1F("Pyc","Momentum en y del K^{+}",500,-5,5);	
  PyC->GetXaxis()->SetTitle("Momentum en y");
  PyC->GetYaxis()->SetTitle("Frecuencia");
  PyC->GetXaxis()->CenterTitle();
  PyC->GetYaxis()->CenterTitle();
  PyC->SetLineColor(4);
  PzC = new TH1F("Pzc","Momentum en z del K^{+}",500,-5,5);	
  PzC->GetXaxis()->SetTitle("Momentum en z");
  PzC->GetYaxis()->SetTitle("Frecuencia");
  PzC->GetXaxis()->CenterTitle();
  PzC->GetYaxis()->CenterTitle();
  PzC->SetLineColor(4);
  EC = new TH1F("EC","Energ#acute{i}a del K^{+}",500,-5,5);	
  EC->GetXaxis()->SetTitle("Energ#acute{i}a");
  EC->GetYaxis()->SetTitle("Frecuencia");
  EC->GetXaxis()->CenterTitle();
  EC->GetYaxis()->CenterTitle();
  EC->SetLineColor(4);
  //Centro de Masas
  dktetacm = new TH1F("dktetacm","Distribuci#acute{o}n del #acute{a}ngulo #theta del K^{+} en el CM",200, 0, 180);
  dktetacm->GetXaxis()->SetTitle(" #acute{A}ngulo #theta");
  dktetacm->GetYaxis()->SetTitle("Frecuencia");
  dktetacm->GetXaxis()->CenterTitle();
  dktetacm->GetYaxis()->CenterTitle();
  dktetacm->SetLineColor(4);
  dkcoscm = new TH1F("Dkcoscm","Distribuci#acute{o}n del cos(#theta) del K^{+} en el CM",1000, -1, 1);
  dkcoscm->GetXaxis()->SetTitle("cos(#theta)");
  dkcoscm->GetYaxis()->SetTitle("Frecuencia");
  dkcoscm->GetXaxis()->CenterTitle();
  dkcoscm->GetYaxis()->CenterTitle();
  dkcoscm->SetLineColor(4);
  dkphicm = new TH1F("Dkphicm","Distribuci#acute{o}n del #acute{a}ngulo #phi del K^{+} en el CM",1000, -180, 180);
  dkphicm->GetXaxis()->SetTitle("#acute{A}ngulo #Phi");
  dkphicm->GetYaxis()->SetTitle("Frecuencia");
  dkphicm->GetXaxis()->CenterTitle();
  dkphicm->GetYaxis()->CenterTitle();
  dkphicm->SetLineColor(4);
  PxcmC = new TH1F("PxcmC","Momentum en x del K^{+} en el CM",500,-5,5);	
  PxcmC->GetXaxis()->SetTitle("Momentum en x CM");
  PxcmC->GetYaxis()->SetTitle("Frecuencia");
  PxcmC->GetXaxis()->CenterTitle();
  PxcmC->GetYaxis()->CenterTitle();
  PxcmC->SetLineColor(4);
  PycmC = new TH1F("PycmC","Momentum en y del K^{+} en el CM",500,-5,5);	
  PycmC->GetXaxis()->SetTitle("Momentum en y CM");
  PycmC->GetYaxis()->SetTitle("Frecuencia");
  PycmC->GetXaxis()->CenterTitle();
  PycmC->GetYaxis()->CenterTitle();
  PycmC->SetLineColor(4);
  PzcmC = new TH1F("PzcmC","Momentum en z del K^{+} en el CM",500,-5,5);	
  PzcmC->GetXaxis()->SetTitle("Momentum en z CM");
  PzcmC->GetYaxis()->SetTitle("Frecuencia");
  PzcmC->GetXaxis()->CenterTitle();
  PzcmC->GetYaxis()->CenterTitle();
  PzcmC->SetLineColor(4);
  
  PtcmC = new TH1F("PtcmC","Momentum total del K^{+} en el CM",500,-5,5);	
  PtcmC->GetXaxis()->SetTitle("Momentum total CM");
  PtcmC->GetYaxis()->SetTitle("Frecuencia");
  PtcmC->GetXaxis()->CenterTitle();
  PtcmC->GetYaxis()->CenterTitle();
  PtcmC->SetLineColor(4);
   
  EcmC = new TH1F("EcmC","Energ#acute{i}a del K^{+} en el CM",500,-5,5);	
  EcmC->GetXaxis()->SetTitle("Energ#acute{i}a");
  EcmC->GetYaxis()->SetTitle("Frecuencia");
  EcmC->GetXaxis()->CenterTitle();
  EcmC->GetYaxis()->CenterTitle();
  EcmC->SetLineColor(4);

  
  Lambda->cd();
  Lambda->SetNameTitle("Lambda","Lambda");
  //Laboratorio	
  masald = new TH1F("masald","Masa del #Lambda_{0}",150,(ML-0.1),(ML+0.1)); 
  masald->GetXaxis()->SetTitle("Masa del #Lambda_{0}");
  masald->GetYaxis()->SetTitle("Frecuencia");
  masald->GetXaxis()->CenterTitle();
  masald->GetYaxis()->CenterTitle();
  masald->SetLineColor(4);

  dldteta = new TH1F("dldteta","Distribuci#acute{o}n del #acute{a}ngulo #theta del #Lambda_{0}",200, 0, 180);
  dldteta->GetXaxis()->SetTitle("#acute{A}ngulo #theta");
  dldteta->GetYaxis()->SetTitle("Frecuencia");
  dldteta->GetXaxis()->CenterTitle();
  dldteta->GetYaxis()->CenterTitle();
  dldteta->SetLineColor(4);

  dldcos = new TH1F("Dldcos","Distribuci#acute{o}n del cos(#theta) del #Lambda_{0}",1000, -1, 1);
  
  dldcos->GetXaxis()->SetTitle("cos(#theta)");
  dldcos->GetYaxis()->SetTitle("Frecuencia");
  dldcos->GetXaxis()->CenterTitle();
  dldcos->GetYaxis()->CenterTitle();
  dldcos->SetLineColor(4);

  dldphi = new TH1F("Dldphi","Distribuci#acute{o}n del #acute{a}ngulo #phi del #Lambda_{0}",1000,-180,180);
  dldphi->GetXaxis()->SetTitle("#acute{A}ngulo #Phi");
  dldphi->GetYaxis()->SetTitle("Frecuencia");
  dldphi->GetXaxis()->CenterTitle();
  dldphi->GetYaxis()->CenterTitle();
  dldphi->SetLineColor(4);
  PxD = new TH1F("PxD","Momentum en x del #Lambda_{0}",500,-5,5);	
  PxD->GetXaxis()->SetTitle("Momentum en x");
  PxD->GetYaxis()->SetTitle("Frecuencia");
  PxD->GetXaxis()->CenterTitle();
  PxD->GetYaxis()->CenterTitle();
  PxD->SetLineColor(4);
  PyD = new TH1F("PyD","Momentum en y del #Lambda_{0}",500,-5,5);	
  PyD->GetXaxis()->SetTitle("Momentum en y");
  PyD->GetYaxis()->SetTitle("Frecuencia");
  PyD->GetXaxis()->CenterTitle();
  PyD->GetYaxis()->CenterTitle();
  PyD->SetLineColor(4); 
  PzD = new TH1F("PzD","Momentum en z del #Lambda_{0}",500,-5,5);	
  PzD->GetXaxis()->SetTitle("Momentum en z");
  PzD->GetYaxis()->SetTitle("Frecuencia");
  PzD->GetXaxis()->CenterTitle();
  PzD->GetYaxis()->CenterTitle();
  PzD->SetLineColor(4);
  ED = new TH1F("ED","Energ#acute{i}a del #Lambda_{0}",500,-5,5);	
  ED->GetXaxis()->SetTitle("Energ#acute{i}a");
  ED->GetYaxis()->SetTitle("Frecuencia");
  ED->GetXaxis()->CenterTitle();
  ED->GetYaxis()->CenterTitle();
  ED->SetLineColor(4);
  //Centro de masas

  dldtetacm = new TH1F("dldtetacm","Distribuci#acute{o}n del #acute{a}ngulo #theta del #Lambda_{0} en el CM",200, 0, 180);
  dldtetacm->GetXaxis()->SetTitle("#acute{A}ngulo #theta");
  dldtetacm->GetYaxis()->SetTitle("Frecuencia");
  dldtetacm->GetXaxis()->CenterTitle();
  dldtetacm->GetYaxis()->CenterTitle();
  dldtetacm->SetLineColor(4);

  dldcoscm = new TH1F("Dldcoscm","Distribuci#acute{o}n del cos(#theta) del #Lambda_{0} en el CM",1000, -1, 1);
  dldcoscm->GetXaxis()->SetTitle("cos(#theta)");
  dldcoscm->GetYaxis()->SetTitle("Frecuencia");
  dldcoscm->GetXaxis()->CenterTitle();
  dldcoscm->GetYaxis()->CenterTitle();
  dldcoscm->SetLineColor(4);
  dldphicm = new TH1F("Dldphicm","Distribuci#acute{o}n del #acute{a}ngulo #phi del #Lambda_{0} en el CM",1000, -180, 180);
  dldphicm->GetXaxis()->SetTitle("#acute{A}ngulo #Phi");
  dldphicm->GetYaxis()->SetTitle("Frecuencia");
  dldphicm->GetXaxis()->CenterTitle();
  dldphicm->GetYaxis()->CenterTitle();
  dldphicm->SetLineColor(4);
  PxcmD = new TH1F("PxcmD","Momentum en x del #Lambda_{0} en el CM",500,-5,5);	
  PxcmD->GetXaxis()->SetTitle("Momentum en x");
  PxcmD->GetYaxis()->SetTitle("Frecuencia");
  PxcmD->GetXaxis()->CenterTitle();
  PxcmD->GetYaxis()->CenterTitle();
  PxcmD->SetLineColor(4);
  PycmD = new TH1F("PycmD","Momentum en y del #Lambda_{0} en el CM",500,-5,5);	
  PycmD->GetXaxis()->SetTitle("Momentum en y");
  PycmD->GetYaxis()->SetTitle("Frecuencia");
  PycmD->GetXaxis()->CenterTitle();
  PycmD->GetYaxis()->CenterTitle();
  PycmD->SetLineColor(4);
  PzcmD = new TH1F("PzcmD","Momentum en z del #Lambda_{0} en el CM",500,-5,5);	
  PzcmD->GetXaxis()->SetTitle("Momentum en z");
  PzcmD->GetYaxis()->SetTitle("Frecuencia");
  PzcmD->GetXaxis()->CenterTitle();
  PzcmD->GetYaxis()->CenterTitle();
  PzcmD->SetLineColor(4);
  
  PtcmD = new TH1F("PtcmD","Momentum total del #Lambda_{0} en el CM",500,-5,5);	
  PtcmD->GetXaxis()->SetTitle("Momentum total");
  PtcmD->GetYaxis()->SetTitle("Frecuencia");
  PtcmD->GetXaxis()->CenterTitle();
  PtcmD->GetYaxis()->CenterTitle();
  PtcmD->SetLineColor(4);

  EcmD = new TH1F("EcmD","Energ#acute{i}a del #Lambda_{0} en el CM",500,-5,5);	
  EcmD->GetXaxis()->SetTitle("Energ#acute{i}a");
  EcmD->GetYaxis()->SetTitle("Frecuencia");
  EcmD->GetXaxis()->CenterTitle();
  EcmD->GetYaxis()->CenterTitle();
  EcmD->SetLineColor(4);

  
  Invariantes->cd();
  Invariantes->SetNameTitle("Invariantes","Invariantes");
  SLabi = new TH1F("SLabi","Canal s Lab, estado inicial",1000, 0,5);
  SLabi->GetXaxis()->SetTitle("s^{2}");
  SLabi->GetYaxis()->SetTitle("Frecuencia");
  SLabi->GetYaxis()->CenterTitle();
  SLabi->SetLineColor(1);

  SLabf = new TH1F("SLabf","Canal s Lab, estado final",1000, 0,5);
  SLabf->GetXaxis()->SetTitle("s^{2}");
  SLabf->GetYaxis()->SetTitle("Frecuencia");
  SLabf->GetYaxis()->CenterTitle();
  SLabf->SetLineColor(1);

 
  SCmi = new TH1F("SCmi","Canal s Cm, estado inicial",1000, 0,5);
  SCmi->GetXaxis()->SetTitle("s^{2}");
  SCmi->GetYaxis()->SetTitle("Frecuencia");
  SCmi->GetYaxis()->CenterTitle();
  SCmi->SetLineColor(1);

  SCmf = new TH1F("SCmf","Canal s Cm, estado final",1000, 0,5);
  SCmf->GetXaxis()->SetTitle("s^{2}");
  SCmf->GetYaxis()->SetTitle("Frecuencia");
  SCmf->GetYaxis()->CenterTitle();
  SCmf ->SetLineColor(1);


  canalt1 = new TH1F("canalt1","Canal t, Momentum transferido",1000, -3,0);
  canalt1->GetXaxis()->SetTitle("t^{2}");
  canalt1->GetYaxis()->SetTitle("Frecuencia");
  canalt1->GetXaxis()->CenterTitle();
  canalt1->GetYaxis()->CenterTitle();
  canalt1->SetLineColor(1);

  canalt2 = new TH1F("canalt2","Canal t, Momentum transferido",1000, -3,0);
  canalt2->GetXaxis()->SetTitle("t^{2}");
  canalt2->GetYaxis()->SetTitle("Frecuencia");
  canalt2->GetXaxis()->CenterTitle();
  canalt2->GetYaxis()->CenterTitle();
  canalt2->SetLineColor(1);

  canalu1 = new TH1F("canalu1","Canal u, Momentum transferido",1000, -3,0);
  canalu1->GetXaxis()->SetTitle("u^{2}");
  canalu1->GetYaxis()->SetTitle("Frecuencia");
  canalu1->GetXaxis()->CenterTitle();
  canalu1->GetYaxis()->CenterTitle();
  canalu1->SetLineColor(1);

  canalu2 = new TH1F("canalu2","Canal u, Momentum transferido",1000, -3,0);
  canalu2->GetXaxis()->SetTitle("u^{2}");
  canalu2->GetYaxis()->SetTitle("Frecuencia");
  canalu2->GetXaxis()->CenterTitle();
  canalu2->GetYaxis()->CenterTitle();
  canalu2->SetLineColor(1);

  canalt1cm = new TH1F("canalt1cm","Canal t, centro de masas",1000, -3,0);
  canalt1cm->GetXaxis()->SetTitle("t^{2}");
  canalt1cm->GetYaxis()->SetTitle("Frecuencia");
  canalt1cm->GetXaxis()->CenterTitle();
  canalt1cm->GetYaxis()->CenterTitle();
  canalt1cm->SetLineColor(1);

  canalt2cm = new TH1F("canalt2cm","Momentum transferido canal t2cm",1000, -3,0);
  canalt2cm->GetXaxis()->SetTitle("t^{2}");
  canalt2cm->GetYaxis()->SetTitle("Frecuencia");
  canalt2cm->GetXaxis()->CenterTitle();
  canalt2cm->GetYaxis()->CenterTitle();
  canalt2cm->SetLineColor(1);

  canalu1cm = new TH1F("canalu1cm","Canal u, centro de masas",1000, -3,0);
  canalu1cm->GetXaxis()->SetTitle("u^{2}");
  canalu1cm->GetYaxis()->SetTitle("Frecuencia");
  canalu1cm->GetXaxis()->CenterTitle();
  canalu1cm->GetYaxis()->CenterTitle();
  canalu1cm->SetLineColor(1);

  canalu2cm = new TH1F("canalu2cm","Canal u, centro de masas",1000, -3,0);
  canalu2cm->GetXaxis()->SetTitle("u^{2}");
  canalu2cm->GetYaxis()->SetTitle("Frecuencia");
  canalu2cm->GetXaxis()->CenterTitle();
  canalu2cm->GetYaxis()->CenterTitle();
  canalu2cm->SetLineColor(1);

  
  Comparasiones->cd();  
  Comparasiones->SetNameTitle("Comparaciones","Comparaciones");
  betald = new TH2F("betald","Beta en funci#acute{o}n del momentum del #Lambda_{0}", 500,0,3, 500,0,2);
  betald->GetXaxis()->SetTitle("Momentum");
  betald->GetYaxis()->SetTitle("Beta");
  betald->GetXaxis()->CenterTitle();
  betald->GetYaxis()->CenterTitle();
  betak = new TH2F("betak","Beta en funci#acute{o}n del momentum del K^{+}", 500,0,3, 500,0,2);
  betak->GetXaxis()->SetTitle("Momentum");
  betak->GetYaxis()->SetTitle("Beta");
  betak->GetXaxis()->CenterTitle();
  betak->GetYaxis()->CenterTitle();
  enminld = new TH2F("enminld","Energ#acute{i}a m#acute{i}nima #Lambda_{0}", 500,0, 2.5, 500,0,2);
  enminld->GetXaxis()->SetTitle("Energ#acute{i}a");
  enminld->GetYaxis()->SetTitle("Momentum del #Lambda_{0}");
  enminld->GetXaxis()->CenterTitle();
  enminld->GetYaxis()->CenterTitle();
  enminkp = new TH2F("enminkp","Energ#acute{i}a m#acute{i}nima del K^{+}", 500,0, 2.5, 500,0,2);
  enminkp->GetXaxis()->SetTitle("Energ#acute{i}a");
  enminkp->GetYaxis()->SetTitle("Momentum del K^{+}");
  enminkp->GetXaxis()->CenterTitle();
  enminkp->GetYaxis()->CenterTitle();
  Energiagcm = new TH1F("Energiagcm","Energ#acute{i}a del beam en el centro de masas", 500,0, 2);
  Energiagcm->GetXaxis()->SetTitle("Energ#acute{i}a del beam, centro de masas");
  Energiagcm->GetYaxis()->SetTitle("Frecuencia");
  Energiagcm->GetXaxis()->CenterTitle();
  Energiagcm->GetYaxis()->CenterTitle();
  Energiagcm->SetLineColor(4);
  Energiapcm = new TH1F("Energiapcm","Energ#acute{i}a del target en el centro de masas", 500,0,2);
  Energiapcm->GetXaxis()->SetTitle("Energ#acute{i}a del target, centro de masas");
  Energiapcm->GetYaxis()->SetTitle("Frecuencia");
  Energiapcm->GetXaxis()->CenterTitle();
  Energiapcm->GetYaxis()->CenterTitle();
  Energiapcm->SetLineColor(4);

}
  //:::::::::.Nombres a los histogramas segun la reaccion:::::::::://
void WMainProceso::ReactHist(){
  if(Mbarion==MP and Mmeson==MPI0){
    gSystem->ProcessEvents();
    Kaon->SetNameTitle("Pion0","Pion0");
    Lambda->SetNameTitle("Proton","Proton");
    
    masak->SetNameTitle("masap0","Masa del #pi^{0}");
    masak->SetBins(50,(MPI0-0.001),(MPI0+0.001));
    masak->GetXaxis()->SetTitle("Masa del #pi^{0}");
    dkteta->SetNameTitle("Dp0teta","Distribuci#acute{o}n del #acute{a}ngulo #theta del #pi^{0}");
    dkcos->SetNameTitle("Dp0cos","Distribuci#acute{o}n del  cos(#theta) del #pi^{0}");
    dkphi->SetNameTitle("Dp0phi","Distribuci#acute{o}n del  #acute{a}ngulo #phi del #pi^{0}");
    PxC->SetTitle("Momentum en x del #pi^{0}");
    PyC->SetTitle("Momentum en y del #pi^{0}");
    PzC->SetTitle("Momentum en z del #pi^{0}");
    EC->SetTitle("Enrg#acute{i}a del #pi^{0}");
    dktetacm->SetNameTitle("Dp0tetacm","Distribuci#acute{o}n del #acute{a}ngulo #theta del #pi^{0}");
    dkcoscm->SetNameTitle("Dp0coscm","Distribuci#acute{o}n del cos(#theta) del #pi^{0} en el CM");
    dkphicm->SetNameTitle("Dp0phicm","Distribuci#acute{o}n del #acute{a}ngulo #phi del #pi^{0}");
    PxcmC->SetTitle("Momentum en x del #pi^{0} en el CM");
    PycmC->SetTitle("Momentum en y del #pi^{0} en el CM");
    PzcmC->SetTitle("Momentum en z del #pi^{0} en el CM");
    PtcmC->SetTitle("Momentum total del #pi^{0} en el CM");
    EcmC->SetTitle("Energ#acute{i}a del #pi^{0} en el CM");
    masald->SetNameTitle("masap","Masa del p");
    masald->SetBins(50,(MP-0.001),(MP+0.001));
    masald->GetXaxis()->SetTitle("Masa del p");
    dldteta->SetNameTitle("Dpteta","Distribuci#acute{o}n del #acute{a}ngulo #theta del p");
    dldcos->SetNameTitle("Dpcos","Distribuci#acute{o}n del  cos(#theta) del p");
    dldphi->SetNameTitle("Dpphi","Distribuci#acute{o}n del  #acute{a}ngulo #phi del p");
    PxD->SetTitle("Momentum en x del p");
    PyD->SetTitle("Momentum en y del p");
    PzD->SetTitle("Momentum en z del p");
    ED->SetTitle("Enrg#acute{i}a del p");
    dldtetacm->SetNameTitle("Dptetacm","Distribuci#acute{o}n del #acute{a}ngulo #theta del p");
    dldcoscm->SetNameTitle("Dpcoscm","Distribuci#acute{o}n del cos(#theta) del p en el CM");
    dldphicm->SetNameTitle("Dpphicm","Distribuci#acute{o}n del #acute{a}ngulo #phi del p");
    PxcmD->SetTitle("Momentum en x del p en el CM");
    PycmD->SetTitle("Momentum en y del p en el CM");
    PzcmD->SetTitle("Momentum en z del p en el CM");
    PtcmD->SetTitle("Momentum total del p en el CM");
    EcmD->SetTitle("Energ#acute{i}a del p en el CM");
    betald->SetNameTitle("betap","Beta en funci#acute{o}n del momentum del p");
    betak->SetNameTitle("betapi0","Beta en funci#acute{o}n del momentum del #pi^{0}");
    enminld->SetNameTitle("enminp","Energ#acute{i}a m#acute{i}nima p");
    enminld->GetYaxis()->SetTitle("Momentum del p");
    enminkp->SetNameTitle("enmip0p","Energ#acute{i}a m#acute{i}nima #pi^{0}");
    enminkp->GetYaxis()->SetTitle("Momentum del #pi^{0}");
  }

  if(Mbarion==MN and Mmeson==MPIP){
    gSystem->ProcessEvents();
    Kaon->SetNameTitle("Pion+","Pion+");
    Lambda->SetNameTitle("Neutron","Neutron");
    masak->SetNameTitle("masap+","Masa del #pi^{+}");
    masak->SetBins(50,(MPIP-0.001),(MPIP+0.001));
    masak->GetXaxis()->SetTitle("Masa del #pi^{+}");
    dkteta->SetNameTitle("Dp+teta","Distribuci#acute{o}n del #acute{a}ngulo #theta del #pi^{+}");
    dkcos->SetNameTitle("Dp+cos","Distribuci#acute{o}n del  cos(#theta) del #pi^{+}");
    dkphi->SetNameTitle("Dp+phi","Distribuci#acute{o}n del  #acute{a}ngulo #phi del #pi^{+}");
    PxC->SetTitle("Momentum en x del #pi^{+}");
    PyC->SetTitle("Momentum en y del #pi^{+}");
    PzC->SetTitle("Momentum en z del #pi^{+}");
    EC->SetTitle("Enrg#acute{i}a del #pi^{+}");
    dktetacm->SetNameTitle("Dp+tetacm","Distribuci#acute{o}n del #acute{a}ngulo #theta del #pi^{+}");
    dkcoscm->SetNameTitle("Dp+coscm","Distribuci#acute{o}n del cos(#theta) del #pi^{+} en el CM");
    dkphicm->SetNameTitle("Dp+phicm","Distribuci#acute{o}n del #acute{a}ngulo #phi del #pi^{+}");
    PxcmC->SetTitle("Momentum en x del #pi^{+} en el CM");
    PycmC->SetTitle("Momentum en y del #pi^{+} en el CM");
    PzcmC->SetTitle("Momentum en z del #pi^{+} en el CM");
    PtcmC->SetTitle("Momentum total del #pi^{+} en el CM");
    EcmC->SetTitle("Energ#acute{i}a del #pi^{+} en el CM");
    masald->SetNameTitle("masap","Masa del p");
    masald->SetBins(50,(MN-0.001),(MN+0.001));
    masald->GetXaxis()->SetTitle("Masa del n");
    dldteta->SetNameTitle("Dnteta","Distribuci#acute{o}n del #acute{a}ngulo #theta del n");
    dldcos->SetNameTitle("Dncos","Distribuci#acute{o}n del  cos(#theta) del n");
    dldphi->SetNameTitle("Dnphi","Distribuci#acute{o}n del  #acute{a}ngulo #phi del n");
    PxD->SetTitle("Momentum en x del n");
    PyD->SetTitle("Momentum en y del n");
    PzD->SetTitle("Momentum en z del n");
    ED->SetTitle("Enrg#acute{i}a del n");
    dldtetacm->SetNameTitle("Dntetacm","Distribuci#acute{o}n del #acute{a}ngulo #theta del n");
    dldcoscm->SetNameTitle("Dncoscm","Distribuci#acute{o}n del cos(#theta) del n en el CM");
    dldphicm->SetNameTitle("Dnphicm","Distribuci#acute{o}n del #acute{a}ngulo #phi del n");
    PxcmD->SetTitle("Momentum en x del n en el CM");
    PycmD->SetTitle("Momentum en y del n en el CM");
    PzcmD->SetTitle("Momentum en z del n en el CM");
    PtcmD->SetTitle("Momentum total del n en el CM");
    EcmD->SetTitle("Energ#acute{i}a del n en el CM");
    betald->SetNameTitle("betan","Beta en funci#acute{o}n del momentum del n");
    betak->SetNameTitle("betapi+","Beta en funci#acute{o}n del momentum del #pi^{+}");
    enminld->SetNameTitle("enminn","Energ#acute{i}a m#acute{i}nima n");
    enminld->GetYaxis()->SetTitle("Momentum del n");
    enminkp->SetNameTitle("enmip+p","Energ#acute{i}a m#acute{i}nima #pi^{+}");
    enminkp->GetYaxis()->SetTitle("Momentum del #pi^{+}");
  }
}
//---------------------------------------------------------------------//

//---------------------Boton de ayuda----------------------------------//

void WMainProceso::Help(){
  gSystem->ProcessEvents();
  fHelp=new WCHelp(gClient->GetRoot(),MainFrame,20,20);
  fHelp->Draw();
}


//---------Funcion donde se ejecuta el proceso.
void WMainProceso::Execution(){

  Disable();
  BLimpiar->SetEnabled(true);
  
  EG=Energy();
  NEVENT=NEvent();
  loop=Loop();
  
  beta_w.SetXYZ(0.0,0.0,0.0);
  file_name=Name();
  
  
  if(string(file_name).size()!=0){
    sprintf(file_dat,"%s_%d.dat",file_name,run);
    sprintf(file_root,"%s_%d.root",file_name,run);
    f = new TFile(file_root,"RECREATE");              //Creando los archivos Dat y Root
    outfile.open(file_dat);    
    outfile.precision(DIGIT);  
    outfile << NEVENT << endl;
  }
  
  gstyle();
  booking();                                            //Haciendo los histogramas
  ReactHist(); 
  // LOOP DE EVENTOS!!!!!!!!!!!!!!!!!!!!
  
  gRandom->SetSeed();
  
  
  ppl.SetPxPyPzE(0.0,0.0,0.0,MP);
  
  auto start = chrono::high_resolution_clock::now();
  

  for(int j = 0; j<loop; j++){
    if(BLimpiar->IsEnabled()==false){
      break;
    }
    if(loop==1){      //condicion para distribucion de energia
      n=EG;
    }
    else{
      n=gRandom->Uniform(0,EG);}
    
    
    pgl.SetPxPyPzE(0.0,0.0,n,n);
    
    w=(ppl+pgl);                                        // Suma de cuadrimomentos
    
    Double_t masses[2] = { Mbarion, Mmeson};
    TGenPhaseSpace event;                               // Generador de eventos
    event.SetDecay(w, 2, masses);   
    
    
    for(int i = 0; i< NEVENT; i++){
      if(BLimpiar->IsEnabled()==false){break;}

      gSystem->ProcessEvents();
      
      weight=event.Generate();
      TLorentzVector *ppldl = event.GetDecay(0);
      TLorentzVector *ppkpl = event.GetDecay(1);
      pldl = *ppldl;                                    //Momentum de barion en el laboratorio
      pkpl = *ppkpl;                                    //Momentum de meson en el laboratorio    
      
      //Boost sobre el centro de masas
      
      beta = w.Rho()/w.E();                     //Calculando la velocidad del centro de masas
      
      beta_w.SetZ(-beta);
      
      TLorentzRotation LAB_CM;
      
      LAB_CM.Boost(beta_w);                      //Boost sobre el centro de masas  
      
      
      gcm   = 1/sqrt(1-beta*beta);              // Gamma cm
      Ebcm  = gcm*(1-beta)*EG;                  // Energia del foton C.M
      Etcm  = gcm*MP;                           // Energia del target in C.M
      
      pkpcm = LAB_CM*pkpl;                       //Cuadrimomento del meson en el centro de masas
      pldcm = LAB_CM*pldl;                       //Cuadrimomento del barion en el centro de masas
      pptcm = LAB_CM*ppl;                       //Cuadrimomento del target en el centro de masas
      pbcm =  LAB_CM*pgl;                        //Cuadrimomento del beam en el centro de masas
      NEEn->SetNumber(n);
      Slabi = (ppl+pgl);                         // Canal s Lab, estado inicial
      NEVSLab->SetNumber(Slabi.Mag2());
      Slabf = (pldl+pkpl);                       // Canal s Lab, estado final 
      Scmi  = (pptcm+pbcm);                      // Canal s Cm, estado inicial  
      NEVSCM->SetNumber(Scmi.Mag2());
      Scmf  = (pkpcm+pldcm);                     // Canal s Cm, estado final
      
      T1l=(ppl-pldl);                           //Canal T1 laboratorio
      NEVTLab->SetNumber(T1l.Mag2());
      T2l=(pgl-pkpl);                           //Canal T2 laboratorio
      U1l=(ppl-pkpl);                           //Canal U1 laboratorio
      NEVULab->SetNumber(U1l.Mag2());
      U2l=(pgl-pldl);                           //Canal U2 laboratorio
      T1cm=(pptcm-pldcm);                       //canal T1 en el centro de masas
      NEVTCM->SetNumber(T1cm.Mag2());
      T2cm=(pbcm-pkpcm);                                //canal T2 en el centro de masas
      U1cm=(pptcm-pkpcm);                       //Canal U1 en el centro de masas        
      NEVUCM->SetNumber(U1cm.Mag2());
      U2cm=(pbcm-pldcm);                                //canal U2 en el centro de masas

      //llenando Histogramas
      
      masak->Fill(pkpl.M());                            //Masa del meson
      dkcos->Fill(pkpl.CosTheta());                      //Distribucion en coseno theta del meson
      dkteta->Fill(pkpl.Theta()*180.0/TMath::Pi());     //Distribucion en theta del meson   
      dkphi->Fill(pkpl.Phi()*180.0/TMath::Pi());                //Distribucion en phi del meson 
      mld= gRandom->BreitWigner(pldl.M(),0.0156);
      masald->Fill(mld);                                        //Masa del barion
      dldteta->Fill(pldl.Theta()*180.0/TMath::Pi());    //Distribucion en theta del barion
      dldcos->Fill(pldl.CosTheta());                    //Distribucion en cos(theta) del barion
      dldphi->Fill(pkpl.Phi()*180.0/TMath::Pi());         //Distribucion en phi del meson
      dktetacm->Fill(pkpcm.Theta()*180.0/TMath::Pi());     //Distribucion en theta del meson en CM
      dkcoscm->Fill(pkpcm.CosTheta());                          //Distribucion en cos(theta) del meson en CM
      dkphicm->Fill(pkpcm.Phi()*180.0/TMath::Pi());       //Distribucion en phi del meson en CM
      dldtetacm->Fill(pldcm.Theta()*180.0/TMath::Pi());    //Distribucion en theta del barion en CM
      dldcoscm->Fill(pldcm.CosTheta());          //Distribucion en cos(theta) del barion en CM
      dldphicm->Fill(pldcm.Phi()*180.0/TMath::Pi());      //Distribucion en Phi del barion en CM
      
      //Canal s, Laboratorio.
      
      SLabi->Fill(Slabi.M2());                            //Estado inicial                            
      SLabf->Fill(Slabf.M2());                            //Estado final
      
      //Canal s, Centro de masas  
      
      SCmi->Fill(Scmi.M2());                              //Estado inicial                              
      SCmf->Fill(Scmf.M2());
      canalt1->Fill(T1l.M2());                          //canal t1 laboratorio
      canalt2->Fill(T2l.M2());                          //canal t2 laboratorio
      canalu1->Fill(U1l.M2());                          //canal u1 laboratorio
      canalu2->Fill(U2l.M2());                          //canal u2 laboratorio
      
      canalt1cm->Fill(T1cm.M2());                               //canal t1 centro de masas
      canalt2cm->Fill(T2cm.M2());                               //canal t2 centro de masas
      canalu1cm->Fill(U1cm.M2());                               //canal u1 centro de masas
      canalu2cm->Fill(U2cm.M2());                               //canal u2 centro de masas      
      
      //Variables Cinematicas y energia minima
      
      Energiagcm->Fill(pbcm.E());
      Energiapcm->Fill(pptcm.E());       
      
      
      betald->Fill(pldl.Rho(), pldl.Rho()/pldl.E());      // momentum y beta del lambda
      betak->Fill(pkpl.Rho(), pkpl.Rho()/pkpl.E());       // momentum y beta del kaon  
      
      enminld->Fill(pgl.E(),pldl.Rho());                        //Energia minima para producir un lambda
      enminkp->Fill(pgl.E(),pkpl.Rho());                        //Energia minima para producir un kaon
      
      //variables cinematicas del Kaon
      
      PxC->Fill(pkpl.Px());                             //Momentun en x del meson
      PyC->Fill(pkpl.Py());                             //Momentun en y del meson
      PzC->Fill(pkpl.Pz());                             //Momentun en z del meson
      EC->Fill(pkpl.E());                                       //Energia del meson
      PxcmC->Fill(pkpcm.Px());                          //Momentun en x del meson cm
      PycmC->Fill(pkpcm.Py());                          //Momentun en y del meson cm
      PzcmC->Fill(pkpcm.Pz());                          //Momentun en z del meson cm
      PtcmC->Fill(pkpcm.Rho());                         //Momentum total del meson cm    
      EcmC->Fill(pkpcm.E());                            //Energia del meson cm
      //variables cinematicas del barion
      
      PxD->Fill(pldl.Px());                             //Momentun en x del barion
      PyD->Fill(pldl.Py());                             //Momentun en y del barion
      PzD->Fill(pldl.Pz());                             //Momentun en z del barion
      ED->Fill(pldl.E());                               //Energia del barion
      
      PxcmD->Fill(pldcm.Px());                          //Momentun en x del barion cm
      PycmD->Fill(pldcm.Py());                          //Momentun en y del barion cm
      PzcmD->Fill(pldcm.Pz());                          //Momentun en z del barion cm
      PtcmD->Fill(pldcm.Rho());                         //Momentum total del barion cm  
      EcmD->Fill(pldcm.E());                            //Energia del barion cm
      
      //Dibujando los histogramas
      if(loop==1)
	{
	  if(NEVENT<=100)
	    {
	      DrawHist();
	    }	  
	  if((NEVENT>100)and (NEVENT<=1000))
	    {
	      if(((i+1)%5==0) or (i+1==NEVENT))
		{
		  DrawHist();
		}	      
	    }	  
	  if((NEVENT>1000)and (NEVENT<=10000))
	    {
	      if(((i+1)%50==0) or (i+1==NEVENT))
		{
		  DrawHist();
		}	    
	    }	  
	  if((NEVENT>10000)and (NEVENT<=100000))
	    {
	      if(((i+1)%500==0) or (i+1==NEVENT))
		{
		  DrawHist();
		}	      
	    }	  
	  if((NEVENT>100000)and (NEVENT<=1000000))
	    {
	      if(((i+1)%5000==0) or (i+1==NEVENT))
		{
		  DrawHist();
		}	      
	    }	  
	  if((NEVENT>100000)and (NEVENT<=1000000))
	    {
	      if(((i+1)%5000==0) or (i+1==NEVENT))
		{
		  DrawHist();
		}	      
	    }
	  if(NEVENT<1000000)
	    {
	      if(((i+1)%500000==0) or (i+1==NEVENT))
		{
		  DrawHist();
		}	  
	    }	  
	  
	  //Dibujando el choque
	  if(i==0){
	    gSystem->ProcessEvents();
	    gClient->HandleInput();           
	    move();
	    CLab->Clear();
	    CLab->Update();
	    CCM->Clear();
	    CCM->Update();
	  }
	}
      //---------------------------
      else if((loop>1)and(loop<=100))
	{	  
	  if((i==0) or (i+1)==NEVENT)
	    {
	      DrawHist();
	    }
	  //Dibujando el choque
	  if(((j==0) and (i==0))or((j+1==loop)and(i+1==NEVENT)))
	    {
	      gSystem->ProcessEvents();
	      gClient->HandleInput();           
	      move();
	      CLab->Clear();
	      CLab->Update();
	      CCM->Clear();
	      CCM->Update();
	    }
      }
      
      else if((loop>100)and(loop<=1000))
	{
	  if(((j+1)%5==0)or((j+1)==loop))
	    {
	      //Dibujando el choque
	      if((i==0) or (i+1)==NEVENT)
		{
		  DrawHist();
		}	      
	    }
	  if(((j==0) and (i==0))or((j+1==loop)and(i+1==NEVENT)))
	    {
	      gSystem->ProcessEvents();
	      gClient->HandleInput();           
	      move();
	      CLab->Clear();
	      CLab->Update();
	      CCM->Clear();
	      CCM->Update();
	    }
	}
      
      else if((loop>1000)and(loop<=10000))
	{
	  if(((j+1)%50==0)or((j+1)==loop))
	    {
	      //Dibujando el choque
	      if((i==0) or (i+1)==NEVENT)
		{
		  DrawHist();
		}	      
	    }
	  if(((j==0) and (i==0))or((j+1==loop)and(i+1==NEVENT)))
	    {
	      gSystem->ProcessEvents();
	      gClient->HandleInput();           
	      move();
	      CLab->Clear();
	      CLab->Update();
	      CCM->Clear();
	      CCM->Update();
	    }
	}
      
      else if((loop>10000)and(loop<=100000))
	{
	  if(((j+1)%500==0)or((j+1)==loop))
	    {
	      //Dibujando el choque
	      if((i==0) or (i+1)==NEVENT)
		{
		  DrawHist();
		}	      
	    }
	  if(((j==0) and (i==0))or((j+1==loop)and(i+1==NEVENT)))
		{
		  gSystem->ProcessEvents();
		  gClient->HandleInput();           
		  move();
		  CLab->Clear();
		  CLab->Update();
		  CCM->Clear();
		  CCM->Update();
		}
	}
      
      else if(loop>100000)
	{
	  if(((j+1)%5000==0)or((j+1)==loop))
	    {
	      //Dibujando el choque
	      if((i==0) or (i+1)==NEVENT)
		{
		  DrawHist();
		}	      
	    }
	  if(((j==0) and (i==0))or((j+1==loop)and(i+1==NEVENT)))
	    {
	      gSystem->ProcessEvents();
	      gClient->HandleInput();           
	      move();
	      CLab->Clear();
	      CLab->Update();
	      CCM->Clear();
	      CCM->Update();
	    }
	}
      
      //------------Final del if para refresh      
    }
    //----Final del for   
  }  
  auto finnish = chrono::high_resolution_clock::now();
  chrono::duration<double> elapsed=finnish-start;
  cout<<"Tiempo de ejecución: "<<elapsed.count()<<"s\n";
  // Escribiendo la informacion en los archivos de salida
  
  if(string(file_name).size()!=0){
    outfile << masak << " ";    
    outfile << dkcos << " ";
    outfile << dkteta << " ";                       
    outfile << dkphi << " "; 
    outfile << masald << " ";
    outfile << dldteta << " ";              
    outfile << dldcos << " ";                  
    outfile << dldphi << " "; 
    outfile << dkcoscm << " "; 
    outfile << dktetacm << " "; 
    outfile << dkphicm << " "; 
    outfile << dldtetacm << " "; 
    outfile << dldcoscm << " "; 
    outfile << dldphicm << " "; 
    outfile << SLabi << " ";
    outfile << SLabf << " ";
    outfile << SCmi << " ";
    outfile << SCmf << " ";
    outfile << canalt1 << " "; 
    outfile << canalt2 << " ";
    outfile << canalu1 << " ";
    outfile << canalu2 << " ";
    outfile << canalt1cm << " ";
    outfile << canalt2cm << " ";
    outfile << canalu1cm << " ";
    outfile << canalu2cm << " ";
    outfile << betald << " "; 
    outfile << betak << " ";  
    outfile << enminld << " "; 
    outfile << enminkp << " "; 
    outfile << Energiagcm << " ";
    outfile << Energiapcm << " ";
    outfile << PxC << " ";
    outfile << PyC << " ";
    outfile << PzC << " ";
    outfile << EC << " ";
    outfile << PxcmC << " ";
    outfile << PycmC << " ";       
    outfile << PzcmC << " ";
    outfile << EcmC << " ";
    outfile << PtcmC << " ";
    outfile << PxD << " ";
    outfile << PyD << " ";
    outfile << PzD << " ";
    outfile << ED << " ";
    outfile << PxcmD << " ";
    outfile << PycmD << " ";       
    outfile << PzcmD << " ";
    outfile << PtcmD << " ";
    outfile << EcmD << " ";
   
    f->Write();                   // escribiendo sobre el archivo de histogramas
    f->Close();
  }
  
  Enable();
}
