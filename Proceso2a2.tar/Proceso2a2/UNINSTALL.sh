###########################################################################
##                                                                       ##
## NOTICE OF COPYRIGHT                                                   ##
##                                                                       ##
##                       Copyright (C) 2020                              ##
##            Ivan Castaneda*- Manuel Segura*- Julian Salamanca*         ##
##                                                                       ##
##                idcastanedab@correo.udistrital.edu.co*                 ##
##                 masegurad@correo.udistrital.edu.co*                   ##
##    jasalamanca@udistrital.edu.co* (profesor Universidad Distrital)    ##
##         Grupo de Fisica e Informatica (FISINFOR) Universidad          ##
##                  Distrital Francisco Jose de Caldas                   ##
##                                                                       ##
##                                                                       ##
##                https://github.com/fisinforgh/Proceso2a2.git           ##
##                                                                       ##
## This program is free software; you can redistribute it and#or modify  ##
## it under the terms of the GNU General Public License as published by  ##
## the Free Software Foundation; either version 2 of the License, or     ##
## (at your option) any later version.                                   ##
##                                                                       ##
## This program is distributed in the hope that it will be useful,       ##
## but WITHOUT ANY WARRANTY; without even the implied warranty of        ##
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         ##
## GNU General Public License for more details:                          ##
##                                                                       ##
##               http://www.gnu.org/copyleft/gpl.html                    ##
##                                                                       ##
###########################################################################

#bin/bash
echo "Para continuar con la desinstalacion, ¡necesita permisos de superusuario!"
echo "Eliminando archivos..."
sudo rm -r /usr/share/proceso2a2
rm Proceso2a2
rm ProcesoDict*
sudo rm /usr/bin/Proceso2a2
#sudo rm ~/.local/share/applications/proceso2a2.desktop
sudo rm /usr/share/applications/proceso2a2.desktop
echo "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"
echo "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::"
echo "¡Ha sido exitoso el proceso de desinstalacion!"
