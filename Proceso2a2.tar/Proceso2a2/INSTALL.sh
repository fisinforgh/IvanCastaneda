###########################################################################
##                                                                       ##
## NOTICE OF COPYRIGHT                                                   ##
##                                                                       ##
##                       Copyright (C) 2018                              ##
##            Ivan Castaneda - Julian Salamanca - Manuel Segura          ##
##                                                                       ##
##                idcastanedab@correo.udistrital.edu.co                  ##
##                   jasalamanca@udistrital.edu.co                       ##
##                                                                       ##
##         Grupo de Fisica e Informatica (FISINFOR) Universidad          ##
##                  Distrital Francisco Jose de Caldas                   ##
##                                                                       ##
##                                                                       ##
##                https://github.com/fisinforgh/Proceso2a2.git           ##
##                                                                       ##
## This program is free software; you can redistribute it and#or modify  ##
## it under the terms of the GNU General Public License as published by  ##
## the Free Software Foundation; either version 2 of the License, or     ##
## (at your option) any later version.                                   ##
##                                                                       ##
## This program is distributed in the hope that it will be useful,       ##
## but WITHOUT ANY WARRANTY; without even the implied warranty of        ##
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         ##
## GNU General Public License for more details:                          ##
##                                                                       ##
##               http://www.gnu.org/copyleft/gpl.html                    ##
##                                                                       ##
###########################################################################

#bin/bash
clear
DIR="`pwd`"
BIN="/usr/bin"
LOCAL="/usr/share/proceso2a2/"
#LAUNCHER="/home/$USER/.local/share/applications/"
LAUNCHER="/usr/share/applications/"
ans="find /usr/bin/ -iname root*"
if [  "${ans:-NULL}" = "NULL" ];
then
    echo "Es necesario instalar ROOT framework"
else
    ans="`dpkg -l | grep xutils-dev`"
    if [ "${ans:-NULL}" =  "NULL" ];
    then
        echo "Es necesario instalar el paquete xutils-dev"
        echo "Para instalarlo ejecute:"
        echo "sudo apt-get install xutis-dev"
    else
        echo "xutils-dev está instalado"
        echo "  "
        echo "  "
        echo "Instalando..."
        echo "Para continuar es necesario dar permisos de superusuario"
        sudo mkdir $LOCAL
        sudo cp -r icons/* $LOCAL
        sudo cp -r include/* $LOCAL
        sudo cp -r sources/* $LOCAL
        sudo cp -r Proceso2a2.cxx $LOCAL
        sudo cp -r ProcesoDict* $LOCAL
        echo "¡Creando archivos!"
        rootcint -f ProcesoDict.cxx -c  include/WCHelp.h include/WMainProceso.h ProcessDef.h 
        g++ -o Proceso2a2 Proceso2a2.cxx ProcesoDict.cxx `root-config --glibs --cflags`
        echo "............................."
        echo "............................."
        echo "Compilando satisfactoriamente"
        echo "............................."
        echo "Creando vinculo"
        sudo cp -r $DIR/Proceso2a2 $LOCAL/Proceso2a2
        echo "aqui1"
        sudo ln -s $LOCAL/Proceso2a2 $BIN/Proceso2a2
        echo $LAUNCHER
        echo "aqui2"
        sudo cp -r $DIR/files/proceso2a2.desktop $LAUNCHER
        echo "aqui3"
        sudo chmod ugo+xwr -R $LOCAL
        sudo chmod u+xwr $BIN/Proceso2a2
        sudo chmod u+x $LAUNCHER/proceso2a2.desktop
        echo "¡Instalacion completada exitosamente!"
        echo "Para correr Proceso2a2 desde la terminal ejecute:"
        echo "$ Proceso2a2"
    fi
fi
