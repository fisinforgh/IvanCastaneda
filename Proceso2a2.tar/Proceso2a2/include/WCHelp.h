///////////////////////////////////////////////////////////////////////////
//                                                                       //
// NOTICE OF COPYRIGHT                                                   //
//                                                                       //
//                       Copyright (C) 2018                              //
//            Ivan Castaneda - Julian Salamanca - Manuel Segura          //
//                                                                       //
//                idcastanedab@correo.udistrital.edu.co                  //
//                   jasalamanca@udistrital.edu.co                       //
//                                                                       //
//         Grupo de Fisica e Informatica (FISINFOR) Universidad          //
//                  Distrital Francisco Jose de Caldas                   //
//                                                                       //
//                                                                       //
//                https://github.com/fisinforgh/Proceso2a2.git           //
//                                                                       //
// This program is free software; you can redistribute it and/or modify  //
// it under the terms of the GNU General Public License as published by  //
// the Free Software Foundation; either version 2 of the License, or     //
// (at your option) any later version.                                   //
//                                                                       //
// This program is distributed in the hope that it will be useful,       //
// but WITHOUT ANY WARRANTY; without even the implied warranty of        //
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         //
// GNU General Public License for more details:                          //
//                                                                       //
//               http://www.gnu.org/copyleft/gpl.html                    //
//                                                                       //
///////////////////////////////////////////////////////////////////////////

//:::::::::Clase para la construccion de la ventana auxiliar::::::://
#ifndef PROCESS_WCHelp
#define PROCESS_WCHelp

#include <TGFrame.h>
#include <TPaveText.h>
#include <TGWindow.h>
#include <TCanvas.h>
#include <TGButton.h>
#include <TRootEmbeddedCanvas.h>
#include <RQ_OBJECT.h>
#include <TSystem.h>
#include <TGClient.h>
using namespace std;

class WCHelp{
  RQ_OBJECT("WCHelp");
 private:
  
  TGTransientFrame *fWCHelp;
  TGVerticalFrame *VFH;
  
  TCanvas *CHelp;
  TRootEmbeddedCanvas *ECHelp;
  TPaveText *PaveHelp[2];

  TGTextButton *TBClose;
  
 public:
  WCHelp(const TGWindow *p, const TGWindow *main, UInt_t w, UInt_t h);  
  virtual ~WCHelp();
  void Draw();
  void Close();
  
  
  ClassDef(WCHelp,0);
};
#endif
