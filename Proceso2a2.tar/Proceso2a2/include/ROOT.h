///////////////////////////////////////////////////////////////////////////
//                                                                       //
// NOTICE OF COPYRIGHT                                                   //
//                                                                       //
//                       Copyright (C) 2018                              //
//             Manuel Segura - Julian Salamanca - Ivan Castaneda         //
//                                                                       //
//                idcastanedab@correo.udistrital.edu.co                  //
//                   jasalamanca@udistrital.edu.co                       //
//                                                                       //
//         Grupo de Fisica e Informatica (FISINFOR) Universidad          //
//                  Distrital Francisco Jose de Caldas                   //
//                                                                       //
//                                                                       //
//                https://github.com/fisinforgh/Proceso2a2.git           //
//                                                                       //
// This program is free software; you can redistribute it and/or modify  //
// it under the terms of the GNU General Public License as published by  //
// the Free Software Foundation; either version 2 of the License, or     //
// (at your option) any later version.                                   //
//                                                                       //
// This program is distributed in the hope that it will be useful,       //
// but WITHOUT ANY WARRANTY; without even the implied warranty of        //
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         //
// GNU General Public License for more details:                          //
//                                                                       //
//               http://www.gnu.org/copyleft/gpl.html                    //
//                                                                       //
///////////////////////////////////////////////////////////////////////////
#ifndef __ALL_ROOT_HEADER_H
#define __ALL_ROOT_HEADER_H

#include <chrono>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <Hoption.h>
#include <Hparam.h>
#include <TApplication.h>
#include <TF1.h>
#include <TF2.h>
#include <TFile.h>
#include <TFrame.h>
#include <TGenPhaseSpace.h>
#include <TGraph.h>
#include <TGraphErrors.h>
#include <TH1.h>
#include <TH2.h>
#include <TH3.h>
#include <THistPainter.h>
#include <TLatex.h>
#include <TLine.h>
#include <TLorentzRotation.h>
#include <TLorentzVector.h>
#include <TMarker.h>
#include <TMath.h>

using namespace std;

#endif
