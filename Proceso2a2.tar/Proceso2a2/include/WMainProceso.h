///////////////////////////////////////////////////////////////////////////
//                                                                       //
// NOTICE OF COPYRIGHT                                                   //
//                                                                       //
//                       Copyright (C) 2020                              //
//            Iván Castañeda*- Manuel Segura*- Julián Salamanca*         //
//                                                                       //
//                idcastanedab@correo.udistrital.edu.co*                 //
//		    masegurad@correo.udistrital.edu.co*			 //
//      jasalamanca@udistrital.edu.co* (profesor Universidad Distrital)  //
//              *Grupo de Física e Informática (FISINFOR)		 //
//             Universidad Distrital Francisco José de Caldas            //
//                                                                       //
//                                                                       //
//                https://github.com/fisinforgh/Proceso2a2.git           //
//                                                                       //
// This program is free software; you can redistribute it and/or modify  //
// it under the terms of the GNU General Public License as published by  //
// the Free Software Foundation; either version 2 of the License, or     //
// (at your option) any later version.                                   //
//                                                                       //
// This program is distributed in the hope that it will be useful,       //
// but WITHOUT ANY WARRANTY; without even the implied warranty of        //
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         //
// GNU General Public License for more details:                          //
//                                                                       //
//               http://www.gnu.org/copyleft/gpl.html                    //
//                                                                       //
///////////////////////////////////////////////////////////////////////////
#ifndef ROOT_TGDockableFrame
#include "TGDockableFrame.h"
#endif
#ifndef ROOT_TGMenu
#include "TGMenu.h"
#endif
#ifndef ROOT_TGMdiDecorFrame
#include "TGMdiDecorFrame.h"
#endif
#ifndef ROOT_TG3DLine
#include "TG3DLine.h"
#endif
#ifndef ROOT_TGMdiFrame
#include "TGMdiFrame.h"
#endif
#ifndef ROOT_TGMdiMainFrame
#include "TGMdiMainFrame.h"
#endif
#ifndef ROOT_TGMdiMenu
#include "TGMdiMenu.h"
#endif
#ifndef ROOT_TGListBox
#include "TGListBox.h"
#endif
#ifndef ROOT_TGNumberEntry
#include "TGNumberEntry.h"
#endif
#ifndef ROOT_TGScrollBar
#include "TGScrollBar.h"
#endif
#ifndef ROOT_TGComboBox
#include "TGComboBox.h"
#endif
#ifndef ROOT_TGuiBldHintsEditor
#include "TGuiBldHintsEditor.h"
#endif
#ifndef ROOT_TGuiBldNameFrame
#include "TGuiBldNameFrame.h"
#endif
#ifndef ROOT_TGFrame
#include "TGFrame.h"
#endif
#ifndef ROOT_TGFileDialog
#include "TGFileDialog.h"
#endif
#ifndef ROOT_TGShutter
#include "TGShutter.h"
#endif
#ifndef ROOT_TGButtonGroup
#include "TGButtonGroup.h"
#endif
#ifndef ROOT_TGCanvas
#include "TGCanvas.h"
#endif
#ifndef ROOT_TGFSContainer
#include "TGFSContainer.h"
#endif
#ifndef ROOT_TGuiBldEditor
#include "TGuiBldEditor.h"
#endif
#ifndef ROOT_TGColorSelect
#include "TGColorSelect.h"
#endif
#ifndef ROOT_TGButton
#include "TGButton.h"
#endif
#ifndef ROOT_TGFSComboBox
#include "TGFSComboBox.h"
#endif
#ifndef ROOT_TGLabel
#include "TGLabel.h"
#endif
#ifndef ROOT_TGMsgBox
#include "TGMsgBox.h"
#endif
#ifndef ROOT_TRootGuiBuilder
#include "TRootGuiBuilder.h"
#endif
#ifndef ROOT_TGTab
#include "TGTab.h"
#endif
#ifndef ROOT_TGListView
#include "TGListView.h"
#endif
#ifndef ROOT_TGSplitter
#include "TGSplitter.h"
#endif
#ifndef ROOT_TGStatusBar
#include "TGStatusBar.h"
#endif
#ifndef ROOT_TGListTree
#include "TGListTree.h"
#endif
#ifndef ROOT_TGuiBldGeometryFrame
#include "TGuiBldGeometryFrame.h"
#endif
#ifndef ROOT_TGToolTip
#include "TGToolTip.h"
#endif
#ifndef ROOT_TGToolBar
#include "TGToolBar.h"
#endif
#ifndef ROOT_TRootEmbeddedCanvas
#include "TRootEmbeddedCanvas.h"
#endif
#ifndef ROOT_TCanvas
#include "TCanvas.h"
#endif
#ifndef ROOT_TGuiBldDragManager
#include "TGuiBldDragManager.h"
#endif



#include "Riostream.h"

#include "TArrow.h"
#include "TTimer.h"
#include "TEllipse.h"
#include <TSystem.h>
#include <time.h>
#include "TGClient.h"
#include <iostream>
#include <fstream>
#include "ROOT.h"
#include "TStyle.h"
#include <TRandom3.h>
#include <TRandom2.h>
#include <TGenPhaseSpace.h>
#include <TF1.h>
#include <TF2.h>
#include <TF3.h>
#include "WCHelp.h"

//------------------------------------//
#ifndef PROCESS_WMainProceso
#define PROCESS_WMainProceso

class WMainProceso{
  RQ_OBJECT("WMainProceso");
    private:
  //:::::::::::::::::::::Marco Prncipal::::::::::::::::::::::::::://  
  TGMainFrame *MainFrame;
  TGVerticalFrame *VFMain;
  TGHorizontalFrame *HFViews;
  TGVerticalFrame *VFControl;
  //::::::::::::::Marco para visualixar los choques::::::::::::::://
  TGHorizontalFrame *HFColision;
  TGVerticalFrame *VFLab;  
  TGLabel *LLab;
  TRootEmbeddedCanvas *ECLab;
  Int_t wECLab;
  TCanvas *CLab;
  TGVerticalFrame *VFCM;
  TGLabel *LCM;
  TRootEmbeddedCanvas *ECCM;
  Int_t wECCM;
  TCanvas *CCM;
  //::::::::Marco de agrpacion para insertar los datos::::::::::::://
  TGGroupFrame *GFDatos;
  TGHorizontalFrame *HFDat;
  TGLabel *LEnFot;
  TGNumberEntry *NEEnFo;
  TGNumberEntry *NENE;
  TGLabel *LNE;
  TGHorizontalFrame *HFEn;
  TGLabel *LEn;
  TGNumberEntry *NEEn;
  TGHorizontalFrame *HFFile;
  TGLabel *LLoop;
  TGNumberEntry *NELoop;
  ULong_t ucolor;        
  TGComboBox *CBReaccion;
  TGLabel *LReaccion;
  TGHorizontalFrame *HFVS;
  TGLabel *LVSLab;
  TGNumberEntry *NEVSLab;   
  TGNumberEntry *NEVSCM;  
  TGLabel *LVSCM;
  TGHorizontalFrame *HFVT;
  TGLabel *LVTLab;
  TGNumberEntry *NEVTLab;
  TGNumberEntry *NEVTCM;
  TGLabel *LVTCM;

  TGHorizontalFrame *HFVU;
  TGLabel *LVULab;
  TGNumberEntry *NEVULab;
  TGNumberEntry *NEVUCM;
  TGLabel *LVUCM;

  TGHorizontalFrame *HFSave;
  TGCheckButton *CHBVectors;
  
  TGFont *ufont;         
  
  TGGC   *uGC;           
  
  GCValues_t vale;

  TGTextEntry *TESave;
  TGCheckButton *CHBSave;

  
  //:::::::::::Marco para el boton de ayuda:::::::::://
  TGHorizontalFrame *HFHelp;
  TGTextButton *BHelp;
  
  TGVerticalFrame *VFGraf;
  
  //::::: Marco para los contenedores y los lienzos de los histogramas::://
  TGVerticalFrame *VFGrafLab;
  TGLabel *LGrafLab;
  
  //::::Agrupador de contenedores::::::://
  TGTab *Tab1Lab;
  
  // container of "tab1"
  TGCompositeFrame *CFLab1;   
  // embedded canvas
  TRootEmbeddedCanvas *ECLab1;
  Int_t wECLab1;
  TCanvas *CGrafLab1;
  
  TGCompositeFrame *CFLab2;  
  // embedded canvas
  TRootEmbeddedCanvas *ECLab2;
  Int_t wECLab2;
  TCanvas *CGrafLab2;
  
  TGCompositeFrame *CFLab3;  
  // embedded canvas
  TRootEmbeddedCanvas *ECLab3;
  Int_t wECLab3;
  TCanvas *CGrafLab3;
  
  TGCompositeFrame *CFLab4;  
  // embedded canvas
  TRootEmbeddedCanvas *ECLab4;
  Int_t wECLab4;
  TCanvas *CGrafLab4;
  
  TGCompositeFrame *CFLab5;  
  // embedded canvas
  TRootEmbeddedCanvas *ECLab5;
  Int_t wECLab5;
  TCanvas *CGrafLab5;
  
  TGCompositeFrame *CFLab6;  
  // embedded canvas
  TRootEmbeddedCanvas *ECLab6;
  Int_t wECLab6;
  TCanvas *CGrafLab6;
  
  TGCompositeFrame *CFLab7;  
  // embedded canvas
  TRootEmbeddedCanvas *ECLab7;
  Int_t wECLab7;
  TCanvas *CGrafLab7;
  
  TGHorizontal3DLine *HLGraf; //Linea horizontal que separa los marcos para las graficas.
  //-----------------Marco para los histogramas del centro de masa-----//
  TGVerticalFrame *VFGrafCM;  
  TGLabel *LGrafCM;
  // tab widget
  TGTab *Tab1CM;
  
  // container of "Tab1"
  TGCompositeFrame *CFCM1;
  // embedded canvas
  TRootEmbeddedCanvas *ECGrafCM1;
  Int_t wECGrafCM1;
  TCanvas *CGrafCM1;
  
  TGCompositeFrame *CFCM2;
  // embedded canvas
  TRootEmbeddedCanvas *ECCM2;
  Int_t wECCM2;
  TCanvas *CCM2;
  
  TGCompositeFrame *CFCM3;
  // embedded canvas
  TRootEmbeddedCanvas *ECCM3;
  Int_t wECCM3;
  TCanvas *CCM3;
  
  TGCompositeFrame *CFCM4;
  // embedded canvas
  TRootEmbeddedCanvas *ECCM4;
  Int_t wECCM4;
  TCanvas *CCM4;
  
  TGCompositeFrame *CFCM5;
  // embedded canvas
  TRootEmbeddedCanvas *ECCM5;
  Int_t wECCM5;
  TCanvas *CCM5;
  
  TGCompositeFrame *CFCM6;
  // embedded canvas
  TRootEmbeddedCanvas *ECCM6;
  Int_t wECCM6;
  TCanvas *CCM6;
  
  TGCompositeFrame *CFCM7;
  // embedded canvas
  TRootEmbeddedCanvas *ECCM7;
  Int_t wECCM7;
  TCanvas *CCM7;
  
  TGHorizontalFrame *HFBut;
  TGTextButton *BLimpiar;
  TGTextButton *BPlay;
  TGTextButton *BSalir;
  //---------------------------------------//
  TTimer *cont;
  TEllipse *pllab;
  TEllipse *fklab;        
  TEllipse *plcm;
  TEllipse *fkcm;
  TArrow *apllab;
  TArrow *afklab;
  TArrow *aplcm;
  TArrow *afkcm;
  //---------------------------//
  TFile *f;
  ofstream outfile;
  WCHelp *fHelp;
  //-------------------------
  //Directorios
  const char *file_name = "";              // Nombre del archivo de datos de salida
  char file_dat[50];                       // Archivo de salida Dat 
  char file_root[50];                      // Archivo de salida Root
  const int DIGIT       = 6;               // Numero de decimales del archivo de salida
  
  
  /////////////////////
  // Constantes Fisicas
  /////////////////////
  
  const double TARGET   = 40.0;            
  const double q        = 1.0;              
  const double c        = 299.792428;       
  const double PI       = 3.141592654;
  const double ZERO     = 0.0;
  const double PHI_MAX  = 6.283185307;
  const double PHI_MIN  = 0.0;
  const double TH_MAX   = 6.283185307;
  const double TH_MIN   = 0.0;
  const double MP       = 0.93827;            //Masa del proton en Gev/c^2
  const double ML       = 1.15195;	      //Masa del Lambda en Gev/c^2     
  const double MK       = 0.493679;           //Masa del Meson en Gev/c^2	
  const double MPIP     = 0.13957;	      //Masa del Pion+ en Gev/c^2
  const double MPI0     = 0.13498;   	      //Masa del Pion0 en Gev/c^2
  const double MN	= 0.93956;            //Masa del neutron en Gev/c^2
  TVector3 beta_w;	       		      //Vector centro de masas	
  
  
  /////////////////////
  //Cuadri-momentos ///
  /////////////////////
  
  
  TLorentzVector pkpl;			      //Cuadrimomento del mason en el laboratorio
  TLorentzVector pldl;                        //Cuadrimomento del barion en el laboratorio	 
  TLorentzVector pptcm;			      //Cuadrimomento del target en el centro de masas
  TLorentzVector pbcm;                        //Cuadrimomento del beam en el centro de masas
  TLorentzVector pkpcm;			      //Cuadrimomento del barion en el CM
  TLorentzVector pldcm;                       //Cuadrimomento del meson en el CM	
  TLorentzVector w;			      //Cuadrimomento Total	
  TLorentzVector Slabi;                       //Cuadrimomento Estado inicial Lab
  TLorentzVector Slabf;                       //Cuadrimomento Estado final Lab  
  TLorentzVector Scmi;                                 
  TLorentzVector Scmf;			      //Cuadrimomento Total en centro de 
  
  TLorentzVector T1l;			      //canal T A->C	
  TLorentzVector T2l;		              //Canal T B->D
  TLorentzVector U1l;			      //canal U A->D	
  TLorentzVector U2l;		              //Canal U B->C	
  TLorentzVector T1cm;                        //Canal T en el centro de masas   
  TLorentzVector T2cm;                        //Canal T en el centro de masas 
  TLorentzVector U1cm;                        //Canal U en el centro de masas 
  TLorentzVector U2cm;                        //Canal U en el centro de masas 
  
  
  ///////////////////
  // GLOBAL VARIABLES
  ///////////////////
  double n;
  Double_t weight = 0;
  int ppev;                                   
  int loop=1;
  int NEVENT;                                 
  int run;                                    
  double delta=0.1;
  double central;
  double xmin;
  double xmax;
 
  double mk;			
  double mld;                     //masa con breitwigner
  double Il;
  double Icm;
//Variables Cinematicas
  double EG    = 0.0;             // Energia del haz de fotones
  double gcm   = 0.0;             // Gamma cm
  double Ebcm  = 0.0;             // Energia del foton en el C.M
  double Etcm  = 0.0;             // Energia del target en el C.M   
  double beta  = 0.0;			
  

  TDirectoryFile *Kaon;
  TDirectoryFile *Lambda;
  TDirectoryFile *Invariantes;
  TDirectoryFile *Comparasiones;
  ///////////////
  //Histogramas 1D
  ///////////////
  
  
  TH1F* masak;			//Masa del meson
  
  TH1F* dkcos;                  //Distribucion angular de coseno theta del meson
  TH1F* dkteta;			//Distribucion angular de theta del meson
  TH1F* dkphi;			//Distribucion angular de phi del meson
  TH1F* masald;			//Masa del barion
  TH1F* dldteta;                //Distribucion angular de theta del barion
  TH1F* dldcos;                 //Distribucion angular del cos(theta) del barion
  TH1F* dldphi;			//Distribucion angular de phi del barion
  
  TH1F* dktetacm;	        //Distribucion angular de theta del meson en CM
  TH1F* dkcoscm;	        //Distribucion angular del coseno de theta del meson en CM
  TH1F* dkphicm;		//Distribucion angular de phi del meson en CM
  TH1F* dldtetacm;              //Distribucion angular de theta del barion CM
  TH1F* dldcoscm;               //Distribucion angular del cos(theta) del barion CM
  TH1F* dldphicm;		//Distribucion angular de phi del barion en CM
  
  
  TH1F* SLabi;                  //Canal s Lab, Estado inicial
  TH1F* SLabf;		        //Canal s Lab, Estado final
  TH1F* SCmi;			//Canal s Cm, Estado inicial
  TH1F* SCmf;		        //Canal s Cm, Estado final
  
  TH1F* canalt1;			//canal t1 a->c
  TH1F* canalt2;			//canal t2 b->d
  TH1F* canalu1;			//canal t1 a->d
  TH1F* canalu2;			//canal t2 b->c
  
  TH1F* canalt1cm;		//canal t1cm 
  TH1F* canalt2cm;		//canal t2cm 
  TH1F* canalu1cm;		//canal u1cm 
  TH1F* canalu2cm;		//canal u2cm 
  
  TH1F* Energiagcm;               //Energia del Beam y el Target en el Cm
  TH1F* Energiapcm;
  
  TH2F* betald;			//Beta del barion en funcion del momentum 
  TH2F* betak;			//Beta del meson en funcion del momentum
  TH2F* enminld;			//Energia minima para producir bariones
  TH2F* enminkp;			//Energia minima para producir mesones
  
  TH1F* PxC;			// Momentun en X del meson
  TH1F* PyC;			// Momentun en Y del meson
  TH1F* PzC;			// Momentun en Z del meson
  TH1F* EC;			// Energia del meson
  TH1F* PxcmC;			// Momentun en X del meson
  TH1F* PycmC;			// Momentun en Y del meson
  TH1F* PzcmC;			// Momentun en Z del meson
  TH1F* EcmC;			// Energia del meson
  TH1F* PtcmC;			// Momentum total del meson centro de masas
  
  TH1F* PxD;			// Momentun en X del lambda
  TH1F* PyD;			// Momentun en Y del lambda
  TH1F* PzD;			// Momentun en Z del lambda
  TH1F* ED;			// Energia del lambda
  TH1F* PxcmD;			// Momentun en X del lambda
  TH1F* PycmD;			// Momentun en Y del lambda
  TH1F* PzcmD;			// Momentun en Z del lambda
  TH1F* EcmD;			// Energia del lambda
  TH1F* PtcmD;			// Momentum total del lambda centro de masas
  
  //:::::::::::::::::::::::::::::::::::::::::::::::::::::://
  //:::Declaracion de objetos publicos:::::::::::::::::::://
 public:
  WMainProceso(const TGWindow *p, UInt_t w, UInt_t h);

  virtual ~WMainProceso();
 
  void Clean();
  TLorentzVector ppl;           // Cuadrimomento del Target en el laboratorio
  TLorentzVector pgl;           // Cuadrimomento de Beam
  
  Double_t r=0.25,talab,tdlab,tacm,tdcm,dtlab=0.1,dtcm=0.2;
  double Mmeson;
  double Mbarion;
  
  TVector3 rpl,rpl0,rfl,rfl0,rkl,rkl0,rll,rll0; //posiciones en el laboratorio
  TVector3 rpcm,rpcm0,rfcm,rfcm0,rkcm,rkcm0,rlcm,rlcm0; //posiciones en el centro de masa
 
  Double_t Energy(){return NEEnFo->GetNumber();}
  Int_t NEvent(){return NENE->GetNumber();}
  Int_t Loop(){return NELoop->GetNumber();}
  const char *Name(){return TESave->GetText();}
  void Exit(){
    gSystem->Exit(0,kTRUE);
    gApplication->Terminate();
  }
  void move();  //Movimiento de las particulas.
  void gstyle(){   
    gStyle->SetTitleXOffset(1.25);
    gStyle->SetTitleYOffset(1.45);   
    gStyle->SetMarkerColor(4);   
    gStyle->SetGridStyle(1);   
    gStyle->SetPadGridX(0); 
    gStyle->SetPadGridY(0);
    gStyle->SetOptStat("menr");
    gStyle->SetPadTickX(1);
    gStyle->SetPadTickY(1);
    gStyle->SetTickLength(0.03, "X");
    gStyle->SetTickLength(0.03, "Y");
  }
  double abs_d(double value)
  {    
    double val;
    val = value;
    if(val < 0)
      val = (-1)*val;
    else
      return(val);    
    return(val);
  }
  float azimuth(TLorentzVector p)
  {    
    float ffi = 0;    
    if(p.Px() != 0){
      ffi = atan(p.Py()/p.Px());
      if(p.Px() < 0)
	ffi = PI + ffi;}
    
    else{ 
      if(p.Py() > 0)
	ffi = PI/2;
      else if(p.Py() == 0)
	ffi = 0;
      else
	ffi = -PI/2;}   
    if(ffi < 0)
      ffi = ffi + 2*PI;   
    return ffi;    
  }
  Float_t polar(TLorentzVector ppp)
  {  
    Float_t pang1 = 0;   // Polar angle    
    Float_t ppptot = 0;  // Total momentum
    ppptot = sqrt(ppp.E()*ppp.E() - ppp.M2());   // momentum       
    if(ppptot != 0 && (ppp.Pz()<=ppptot)){
      pang1 = acos(ppp.Pz()/ppptot);}
    else 
      pang1 = 0;   
    return pang1;}
  
  void booking(); 
  void ReactHist();
  
  void DrawHist();
  
  void Reaction(Int_t Opt);
  
  void Help();
  
  void BSave();
  
  void Enable();
  void Disable();
  
 void Execution();
 
 ClassDef(WMainProceso,0);
};
#endif
