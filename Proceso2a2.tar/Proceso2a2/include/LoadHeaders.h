///////////////////////////////////////////////////////////////////////////
//                                                                       //
// NOTICE OF COPYRIGHT                                                   //
//                                                                       //
//                       Copyright (C) 2018                              //
//            Ivan Castaneda - Julian Salamanca - Manuel Segura          //
//                                                                       //
//                idcastanedab@correo.udistrital.edu.co                  //
//                   jasalamanca@udistrital.edu.co                       //
//                                                                       //
//         Grupo de Fisica e Informatica (FISINFOR) Universidad          //
//                  Distrital Francisco Jose de Caldas                   //
//                                                                       //
//                                                                       //
//                https://github.com/fisinforgh/Proceso2a2.git           //
//                                                                       //
// This program is free software; you can redistribute it and/or modify  //
// it under the terms of the GNU General Public License as published by  //
// the Free Software Foundation; either version 2 of the License, or     //
// (at your option) any later version.                                   //
//                                                                       //
// This program is distributed in the hope that it will be useful,       //
// but WITHOUT ANY WARRANTY; without even the implied warranty of        //
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         //
// GNU General Public License for more details:                          //
//                                                                       //
//               http://www.gnu.org/copyleft/gpl.html                    //
//                                                                       //
///////////////////////////////////////////////////////////////////////////

#ifndef __CLING__
#include "WCHelp.h"
#include "../sources/WCHelp.cxx"
#include "WMainProceso.h"
#include "../sources/WMainProceso.cxx"
#endif
